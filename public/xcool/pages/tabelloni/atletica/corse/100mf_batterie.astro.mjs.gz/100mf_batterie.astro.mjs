import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { R as RacesTable } from '../../../../chunks/RacesTable_8zcP5VBi.mjs';
import { $ as $$Layout } from '../../../../chunks/Layout_v259HEkx.mjs';
import { data1, data2, data3 } from '../../../../chunks/100mF_batterie_0rFH8Tpb.mjs';
export { renderers } from '../../../../renderers.mjs';

const $$100MFBatterie = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025 - Medals", "description": "Medal standings for the XCOOL 2025 event." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin:200px 0 50px 0px;">100m piani Femminile - Batterie</h1></center> <!-- hydrate on load for interactivity --> <center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "Batteria 1", "data": data1, "decimals": 2, "finals": false })} </div></center><center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "Batteria 2", "data": data2, "decimals": 2, "finals": false })} </div></center><center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "Batteria 3", "data": data3, "decimals": 2, "finals": false })} </div></center></main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/100mF_batterie.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/100mF_batterie.astro";
const $$url = "/xcool/tabelloni/atletica/corse/100mF_batterie";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$100MFBatterie,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
