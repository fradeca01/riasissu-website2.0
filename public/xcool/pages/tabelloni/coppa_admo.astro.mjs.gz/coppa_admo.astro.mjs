import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_BE-4ZxlD.mjs';
import 'kleur/colors';
import { B as BarChart } from '../../chunks/BarChart_CMu6hnIa.mjs';
import { $ as $$Layout } from '../../chunks/Layout_Abjf1cfq.mjs';
export { renderers } from '../../renderers.mjs';

const totals = [
  { school: "SSC", total: 35 },
  { school: "CSB", total: 48 },
  { school: "SSA", total: 0 },
  { school: "IUSS", total: 12 },
  { school: "ISUFI", total: 0 },
  { school: "SSSAS", total: 16 },
  { school: "SGSS", total: 76 },
  { school: "SSDTW", total: 72 },
  { school: "SSST", total: 27 },
  { school: "SSMC", total: 27 },
  { school: "SSUC", total: 0 }
];

const daisy = new Proxy({"src":"/xcool/_astro/daisy.riIx5BEx.png","width":724,"height":728,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/daisy.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/daisy.png");
							return target[name];
						}
					});

const $$CoppaAdmo = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Medal standings for the XCOOL 2025 event." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:200px;margin-bottom:50px;">Coppa ADMO</h1> ${renderComponent($$result2, "BarChart", BarChart, { "data": totals, "icon": daisy })} </center> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/coppa_admo.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/coppa_admo.astro";
const $$url = "/xcool/tabelloni/coppa_admo";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$CoppaAdmo,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
