import { jsx, jsxs } from 'react/jsx-runtime';
import styled from '@emotion/styled';
import { M as MediaQuery, T as Theme } from './Layout_DbmlHL6U.mjs';
import 'react';
import { f as createComponent, s as spreadAttributes, u as unescapeHTML, r as renderTemplate } from './astro/server_DboVfyth.mjs';
import 'clsx';
import { css } from '@emotion/react';

const StyledContainer = styled.div`
  margin: 0 auto;
  padding: 0 50px;
  width: 100%;

  // max-width: 540px;

  ${MediaQuery.between("md", "lg")} {
    // max-width: 720px;
  }

  ${MediaQuery.between("lg", "xl")} {
    // max-width: 960px;
  }

  ${MediaQuery.between("xl", "xxl")} {
    // max-width: 1140px;
  }

  ${MediaQuery.min("xxl")} {
    // max-width: 1320px;
  }
`;

const Container = ({ children, ...rest }) => {
  if (!children) {
    return null;
  }
  return /* @__PURE__ */ jsx(StyledContainer, { ...rest, children });
};

function createSvgComponent({ meta, attributes, children }) {
  const Component = createComponent((_, props) => {
    const normalizedProps = normalizeProps(attributes, props);
    return renderTemplate`<svg${spreadAttributes(normalizedProps)}>${unescapeHTML(children)}</svg>`;
  });
  Object.defineProperty(Component, "toJSON", {
    value: () => meta,
    enumerable: false
  });
  return Object.assign(Component, meta);
}
const ATTRS_TO_DROP = ["xmlns", "xmlns:xlink", "version"];
const DEFAULT_ATTRS = {};
function dropAttributes(attributes) {
  for (const attr of ATTRS_TO_DROP) {
    delete attributes[attr];
  }
  return attributes;
}
function normalizeProps(attributes, props) {
  return dropAttributes({ ...DEFAULT_ATTRS, ...attributes, ...props });
}

const IconArrowDown = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-arrow-down.BDCzw7Ed.svg","width":30,"height":30,"format":"svg"},"attributes":{"width":"30px","height":"30px","viewBox":"0 0 24 24","fill":"none"},"children":"\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12 3.25C12.4142 3.25 12.75 3.58579 12.75 4L12.75 18.1893L17.4697 13.4697C17.7626 13.1768 18.2374 13.1768 18.5303 13.4697C18.8232 13.7626 18.8232 14.2374 18.5303 14.5303L12.5303 20.5303C12.3897 20.671 12.1989 20.75 12 20.75C11.8011 20.75 11.6103 20.671 11.4697 20.5303L5.46967 14.5303C5.17678 14.2374 5.17678 13.7626 5.46967 13.4697C5.76256 13.1768 6.23744 13.1768 6.53033 13.4697L11.25 18.1893L11.25 4C11.25 3.58579 11.5858 3.25 12 3.25Z\" fill=\"#fff\" />\n"});

const IconArrowCircle = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-arrow-circle.DUoOPlmj.svg","width":50,"height":50,"format":"svg"},"attributes":{"width":"50px","height":"50px","viewBox":"0 0 24 24","fill":"none"},"children":"\n<path d=\"M14 15.6569V10M14 10H8.34315M14 10L5.63604 18.364M10.2432 20.8278C13.0904 21.3917 16.1575 20.5704 18.364 18.364C21.8787 14.8492 21.8787 9.15076 18.364 5.63604C14.8492 2.12132 9.15076 2.12132 5.63604 5.63604C3.42957 7.84251 2.60828 10.9096 3.17216 13.7568\" stroke=\"#fff\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" />\n"});

const IconArrowRight = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-arrow-right.DqPTpFau.svg","width":20,"height":20,"format":"svg"},"attributes":{"width":"100xp","height":"100xp","style":"transform:rotate(90deg);","viewBox":"-4 0 20 20"},"children":"\n    \n    <title>arrow_up [#283]</title>\n    <desc>Created with Sketch.</desc>\n    <defs>\n\n</defs>\n    <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">\n        <g id=\"Dribbble-Light-Preview\" transform=\"translate(-424.000000, -6879.000000)\" fill=\"#fff\">\n            <g id=\"icons\" transform=\"translate(56.000000, 160.000000)\">\n                <path d=\"M374,6719 L368,6724.854 L368,6739 L380,6739 L380,6724.854 L374,6719 Z M374,6721.794 L378,6725.697 L378,6737 L370,6737 L370,6725.697 L374,6721.794 Z\" id=\"arrow_up-[#283]\">\n\n</path>\n            </g>\n        </g>\n    </g>\n"});

const IconFacebook = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-facebook.CiZt8951.svg","width":15,"height":32,"format":"svg"},"attributes":{"fill":"#fff","preserveAspectRatio":"xMidYMid","width":"14.906","height":"32","viewBox":"0 0 14.906 32"},"children":"\n    <path d=\"M14.874,11.167 L14.262,14.207 C14.062,15.208 13.100,15.992 12.072,15.992 L10.000,15.992 L10.000,30.000 C10.000,31.104 9.159,32.000 8.049,32.000 L5.030,32.000 C3.920,32.000 3.017,31.102 3.017,29.999 L3.017,15.992 L2.011,15.992 C0.901,15.992 -0.002,15.095 -0.002,13.991 L-0.002,10.990 C-0.002,9.887 0.901,8.989 2.011,8.989 L3.017,8.989 L3.017,6.003 C3.017,2.716 5.693,0.041 8.994,0.013 C9.015,0.012 9.033,0.001 9.055,0.001 L13.081,0.001 C13.636,0.001 14.000,0.448 14.000,1.000 L14.000,6.000 C14.000,6.553 13.636,7.004 13.081,7.004 L10.061,7.004 L10.060,8.989 L13.079,8.989 C13.645,8.989 14.167,9.228 14.509,9.644 C14.852,10.059 14.985,10.615 14.874,11.167 ZM9.092,10.990 C9.078,10.991 9.067,10.998 9.053,10.998 L9.053,10.998 C8.497,10.997 8.046,10.549 8.047,9.997 L8.047,9.990 C8.047,9.990 8.047,9.990 8.047,9.990 C8.047,9.990 8.047,9.990 8.047,9.990 L8.049,6.003 C8.049,5.450 8.499,5.003 9.055,5.003 L12.074,5.003 L12.074,2.002 L9.094,2.002 C9.077,2.002 9.063,2.011 9.045,2.011 C6.831,2.011 5.030,3.802 5.030,6.003 L5.030,10.005 C5.030,10.558 4.579,11.006 4.023,11.006 C3.996,11.006 3.973,10.992 3.946,10.990 L2.011,10.990 L2.011,13.991 L4.023,13.991 C4.579,13.991 5.030,14.439 5.030,14.992 C5.030,15.044 5.008,15.088 5.000,15.138 L5.000,30.000 L8.049,29.999 L8.049,15.002 C8.049,14.998 8.047,14.995 8.047,14.992 C8.047,14.439 8.497,13.991 9.053,13.991 L12.072,13.991 C12.145,13.991 12.275,13.886 12.288,13.816 L12.857,10.990 L9.092,10.990 Z\" />\n"});

const IconInstagram = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-instagram.BWvvhaKh.svg","width":50,"height":50,"format":"svg"},"attributes":{"width":"50px","height":"50px","viewBox":"0 0 24 24","fill":"none"},"children":"\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16Z\" fill=\"#fff\" />\n<path d=\"M18 5C17.4477 5 17 5.44772 17 6C17 6.55228 17.4477 7 18 7C18.5523 7 19 6.55228 19 6C19 5.44772 18.5523 5 18 5Z\" fill=\"#fff\" />\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M1.65396 4.27606C1 5.55953 1 7.23969 1 10.6V13.4C1 16.7603 1 18.4405 1.65396 19.7239C2.2292 20.8529 3.14708 21.7708 4.27606 22.346C5.55953 23 7.23969 23 10.6 23H13.4C16.7603 23 18.4405 23 19.7239 22.346C20.8529 21.7708 21.7708 20.8529 22.346 19.7239C23 18.4405 23 16.7603 23 13.4V10.6C23 7.23969 23 5.55953 22.346 4.27606C21.7708 3.14708 20.8529 2.2292 19.7239 1.65396C18.4405 1 16.7603 1 13.4 1H10.6C7.23969 1 5.55953 1 4.27606 1.65396C3.14708 2.2292 2.2292 3.14708 1.65396 4.27606ZM13.4 3H10.6C8.88684 3 7.72225 3.00156 6.82208 3.0751C5.94524 3.14674 5.49684 3.27659 5.18404 3.43597C4.43139 3.81947 3.81947 4.43139 3.43597 5.18404C3.27659 5.49684 3.14674 5.94524 3.0751 6.82208C3.00156 7.72225 3 8.88684 3 10.6V13.4C3 15.1132 3.00156 16.2777 3.0751 17.1779C3.14674 18.0548 3.27659 18.5032 3.43597 18.816C3.81947 19.5686 4.43139 20.1805 5.18404 20.564C5.49684 20.7234 5.94524 20.8533 6.82208 20.9249C7.72225 20.9984 8.88684 21 10.6 21H13.4C15.1132 21 16.2777 20.9984 17.1779 20.9249C18.0548 20.8533 18.5032 20.7234 18.816 20.564C19.5686 20.1805 20.1805 19.5686 20.564 18.816C20.7234 18.5032 20.8533 18.0548 20.9249 17.1779C20.9984 16.2777 21 15.1132 21 13.4V10.6C21 8.88684 20.9984 7.72225 20.9249 6.82208C20.8533 5.94524 20.7234 5.49684 20.564 5.18404C20.1805 4.43139 19.5686 3.81947 18.816 3.43597C18.5032 3.27659 18.0548 3.14674 17.1779 3.0751C16.2777 3.00156 15.1132 3 13.4 3Z\" fill=\"#fff\" />\n"});

const IconTwitter = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-twitter.-eebusCm.svg","width":50,"height":50,"format":"svg"},"attributes":{"width":"50px","height":"50px","viewBox":"0 0 24 24","fill":"none"},"children":"\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M19.7828 3.91825C20.1313 3.83565 20.3743 3.75444 20.5734 3.66915C20.8524 3.54961 21.0837 3.40641 21.4492 3.16524C21.7563 2.96255 22.1499 2.9449 22.4739 3.11928C22.7979 3.29366 23 3.6319 23 3.99986C23 5.08079 22.8653 5.96673 22.5535 6.7464C22.2911 7.40221 21.9225 7.93487 21.4816 8.41968C21.2954 11.7828 20.3219 14.4239 18.8336 16.4248C17.291 18.4987 15.2386 19.8268 13.0751 20.5706C10.9179 21.3121 8.63863 21.4778 6.5967 21.2267C4.56816 20.9773 2.69304 20.3057 1.38605 19.2892C1.02813 19.0108 0.902313 18.5264 1.07951 18.109C1.25671 17.6916 1.69256 17.4457 2.14144 17.5099C3.42741 17.6936 4.6653 17.4012 5.6832 16.9832C5.48282 16.8742 5.29389 16.7562 5.11828 16.6346C4.19075 15.9925 3.4424 15.1208 3.10557 14.4471C2.96618 14.1684 2.96474 13.8405 3.10168 13.5606C3.17232 13.4161 3.27562 13.293 3.40104 13.1991C2.04677 12.0814 1.49999 10.5355 1.49999 9.49986C1.49999 9.19192 1.64187 8.90115 1.88459 8.71165C1.98665 8.63197 2.10175 8.57392 2.22308 8.53896C2.12174 8.24222 2.0431 7.94241 1.98316 7.65216C1.71739 6.3653 1.74098 4.91284 2.02985 3.75733C2.1287 3.36191 2.45764 3.06606 2.86129 3.00952C3.26493 2.95299 3.6625 3.14709 3.86618 3.50014C4.94369 5.36782 6.93116 6.50943 8.78086 7.18568C9.6505 7.50362 10.4559 7.70622 11.0596 7.83078C11.1899 6.61019 11.5307 5.6036 12.0538 4.80411C12.7439 3.74932 13.7064 3.12525 14.74 2.84698C16.5227 2.36708 18.5008 2.91382 19.7828 3.91825ZM10.7484 9.80845C10.0633 9.67087 9.12171 9.43976 8.09412 9.06408C6.7369 8.56789 5.16088 7.79418 3.84072 6.59571C3.86435 6.81625 3.89789 7.03492 3.94183 7.24766C4.16308 8.31899 4.5742 8.91899 4.94721 9.10549C5.40342 9.3336 5.61484 9.8685 5.43787 10.3469C5.19827 10.9946 4.56809 11.0477 3.99551 10.9046C4.45603 11.595 5.28377 12.2834 6.66439 12.5135C7.14057 12.5929 7.49208 13.0011 7.49986 13.4838C7.50765 13.9665 7.16949 14.3858 6.69611 14.4805L5.82565 14.6546C5.95881 14.7703 6.103 14.8838 6.2567 14.9902C6.95362 15.4727 7.65336 15.6808 8.25746 15.5298C8.70991 15.4167 9.18047 15.6313 9.39163 16.0472C9.60278 16.463 9.49846 16.9696 9.14018 17.2681C8.49626 17.8041 7.74425 18.2342 6.99057 18.5911C6.63675 18.7587 6.24134 18.9241 5.8119 19.0697C6.14218 19.1402 6.48586 19.198 6.84078 19.2417C8.61136 19.4594 10.5821 19.3126 12.4249 18.6792C14.2614 18.0479 15.9589 16.9385 17.2289 15.2312C18.497 13.5262 19.382 11.1667 19.5007 7.96291C19.51 7.71067 19.6144 7.47129 19.7929 7.29281C20.2425 6.84316 20.6141 6.32777 20.7969 5.7143C20.477 5.81403 20.1168 5.90035 19.6878 5.98237C19.3623 6.04459 19.0272 5.94156 18.7929 5.70727C18.0284 4.94274 16.5164 4.43998 15.2599 4.77822C14.6686 4.93741 14.1311 5.28203 13.7274 5.89906C13.3153 6.52904 13 7.51045 13 8.9999C13 9.28288 12.8801 9.5526 12.6701 9.74221C12.1721 10.1917 11.334 9.92603 10.7484 9.80845Z\" fill=\"#fff\" />\n"});

const IconLinkedIn = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-linkedin.Cr8d3BTd.svg","width":50,"height":50,"format":"svg"},"attributes":{"fill":"#fff","width":"50px","height":"50px","viewBox":"0 0 1920 1920"},"children":"\n    <path d=\"M1168 601.321v74.955c72.312-44.925 155.796-71.11 282.643-71.11 412.852 0 465.705 308.588 465.705 577.417v733.213L1438.991 1920v-701.261c0-117.718-42.162-140.06-120.12-140.06-74.114 0-120.12 23.423-120.12 140.06V1920l-483.604-4.204V601.32H1168Zm-687.52-.792v1318.918H0V600.53h480.48Zm-120.12 120.12H120.12v1078.678h240.24V720.65Zm687.52.792H835.267v1075.316l243.364 2.162v-580.18c0-226.427 150.51-260.18 240.24-260.18 109.55 0 240.24 45.165 240.24 260.18v580.18l237.117-2.162v-614.174c0-333.334-93.573-457.298-345.585-457.298-151.472 0-217.057 44.925-281.322 98.98l-16.696 14.173H1047.88V721.441ZM240.24 0c132.493 0 240.24 107.748 240.24 240.24 0 132.493-107.747 240.24-240.24 240.24C107.748 480.48 0 372.733 0 240.24 0 107.748 107.748 0 240.24 0Zm0 120.12c-66.186 0-120.12 53.934-120.12 120.12s53.934 120.12 120.12 120.12 120.12-53.934 120.12-120.12-53.934-120.12-120.12-120.12Z\" fill-rule=\"evenodd\" />\n"});

const IconGithub = createSvgComponent({"meta":{"src":"/xcool/_astro/icon-github.DH9R7T2y.svg","width":50,"height":50,"format":"svg"},"attributes":{"width":"50px","height":"50px","viewBox":"0 0 24 24","fill":"none"},"children":"\n<path d=\"M4.0744 2.9938C4.13263 1.96371 4.37869 1.51577 5.08432 1.15606C5.84357 0.768899 7.04106 0.949072 8.45014 1.66261C9.05706 1.97009 9.11886 1.97635 10.1825 1.83998C11.5963 1.65865 13.4164 1.65929 14.7213 1.84164C15.7081 1.97954 15.7729 1.97265 16.3813 1.66453C18.3814 0.651679 19.9605 0.71795 20.5323 1.8387C20.8177 2.39812 20.8707 3.84971 20.6494 5.04695C20.5267 5.71069 20.5397 5.79356 20.8353 6.22912C22.915 9.29385 21.4165 14.2616 17.8528 16.1155C17.5801 16.2574 17.3503 16.3452 17.163 16.4167C16.5879 16.6363 16.4133 16.703 16.6247 17.7138C16.7265 18.2 16.8491 19.4088 16.8973 20.4002C16.9844 22.1922 16.9831 22.2047 16.6688 22.5703C16.241 23.0676 15.6244 23.076 15.2066 22.5902C14.9341 22.2734 14.9075 22.1238 14.9075 20.9015C14.9075 19.0952 14.7095 17.8946 14.2417 16.8658C13.6854 15.6415 14.0978 15.185 15.37 14.9114C17.1383 14.531 18.5194 13.4397 19.2892 11.8146C20.0211 10.2698 20.1314 8.13501 18.8082 6.83668C18.4319 6.3895 18.4057 5.98446 18.6744 4.76309C18.7748 4.3066 18.859 3.71768 18.8615 3.45425C18.8653 3.03823 18.8274 2.97541 18.5719 2.97541C18.4102 2.97541 17.7924 3.21062 17.1992 3.49805L16.2524 3.95695C16.1663 3.99866 16.07 4.0147 15.975 4.0038C13.5675 3.72746 11.2799 3.72319 8.86062 4.00488C8.76526 4.01598 8.66853 3.99994 8.58215 3.95802L7.63585 3.49882C7.04259 3.21087 6.42482 2.97541 6.26317 2.97541C5.88941 2.97541 5.88379 3.25135 6.22447 4.89078C6.43258 5.89203 6.57262 6.11513 5.97101 6.91572C5.06925 8.11576 4.844 9.60592 5.32757 11.1716C5.93704 13.1446 7.4295 14.4775 9.52773 14.9222C10.7926 15.1903 11.1232 15.5401 10.6402 16.9905C10.26 18.1319 10.0196 18.4261 9.46707 18.4261C8.72365 18.4261 8.25796 17.7821 8.51424 17.1082C8.62712 16.8112 8.59354 16.7795 7.89711 16.5255C5.77117 15.7504 4.14514 14.0131 3.40172 11.7223C2.82711 9.95184 3.07994 7.64739 4.00175 6.25453C4.31561 5.78028 4.32047 5.74006 4.174 4.83217C4.09113 4.31822 4.04631 3.49103 4.0744 2.9938Z\" fill=\"#fff\" />\n<path d=\"M3.33203 15.9454C3.02568 15.4859 2.40481 15.3617 1.94528 15.6681C1.48576 15.9744 1.36158 16.5953 1.66793 17.0548C1.8941 17.3941 2.16467 17.6728 2.39444 17.9025C2.4368 17.9449 2.47796 17.9858 2.51815 18.0257C2.71062 18.2169 2.88056 18.3857 3.05124 18.5861C3.42875 19.0292 3.80536 19.626 4.0194 20.6962C4.11474 21.1729 4.45739 21.4297 4.64725 21.5419C4.85315 21.6635 5.07812 21.7352 5.26325 21.7819C5.64196 21.8774 6.10169 21.927 6.53799 21.9559C7.01695 21.9877 7.53592 21.998 7.99999 22.0008C8.00033 22.5527 8.44791 23.0001 8.99998 23.0001C9.55227 23.0001 9.99998 22.5524 9.99998 22.0001V21.0001C9.99998 20.4478 9.55227 20.0001 8.99998 20.0001C8.90571 20.0001 8.80372 20.0004 8.69569 20.0008C8.10883 20.0026 7.34388 20.0049 6.67018 19.9603C6.34531 19.9388 6.07825 19.9083 5.88241 19.871C5.58083 18.6871 5.09362 17.8994 4.57373 17.2891C4.34391 17.0194 4.10593 16.7834 3.91236 16.5914C3.87612 16.5555 3.84144 16.5211 3.80865 16.4883C3.5853 16.265 3.4392 16.1062 3.33203 15.9454Z\" fill=\"#fff\" />\n"});

const icons = {
  arrowDown: IconArrowDown,
  arrowCircle: IconArrowCircle,
  arrowRight: IconArrowRight,
  facebook: IconFacebook,
  instagram: IconInstagram,
  twitter: IconTwitter,
  linkedin: IconLinkedIn,
  github: IconGithub
};
const Icon = ({ alt, iconData, ...rest }) => {
  const icon = icons[iconData];
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: icon.src,
      alt,
      width: icon.width,
      height: icon.height,
      "data-icon": "true",
      ...rest
    }
  );
};

const ButtonWrapper = styled.div`
  display: flex;
  justify-content: ${({ $align }) => $align || "flex-start"};
  margin-top: 20px;
`;
const ButtonLink = styled.a`
  text-transform: uppercase;
  transition: 0.3s;
  cursor: pointer;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  position: relative;
  z-index: 2;

  ${({ $variant }) => $variant === "primary" && PrimaryVariant};
  ${({ $variant }) => $variant === "secondary" && SecondaryVariant};
`;
const Button$1 = ButtonLink.withComponent("button");
const PrimaryVariant = css`
  display: inline-flex;
  align-items: center;
  font-size: 25px;
  line-height: 30px;
  padding: 10px;
  margin-top: 40px;
  transition: color 0.5s;
  transition-delay: 0.2s;

  ${MediaQuery.max("lg")} {
    font-size: 20px;
    line-height: 18px;
    margin-top: 20px;
  }

  &:before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 0%;
    background: ${Theme.primary};
    z-index: -1;
    transition: width 0.5s;
  }

  &:after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 1px;
    background: ${Theme.primary};
    transition: width 0.5s;
  }

  &:hover {
    color: ${Theme.secondary};

    &:before {
      width: 100%;
    }

    &:after {
      width: 0%;
    }

    img {
      margin-right: 30px;
      opacity: 1;
    }
  }

  img {
    transition-delay: 0.2s;
    filter: invert(1);
    opacity: 0;
    margin-right: -20px;
    transition: all 0.5s;
  }
`;
const SecondaryVariant = css`
  padding: 12px 40px;
  min-width: 150px;
  border: 1.5px solid ${Theme.tertiary};
  font-size: 16px;
  line-height: 20px;
  letter-spacing: 1px;
  font-weight: 500;
  border-radius: 50px;
  background: ${Theme.tertiary};
  color: ${Theme.primary};

  &:hover {
    background: transparent;
    color: ${Theme.secondary};
  }
`;

const Button = ({
  link,
  target,
  children,
  align,
  showIcon = false,
  variant = "primary",
  asButton,
  type,
  onClick,
  ...rest
}) => {
  const ButtonComponent = asButton ? Button$1 : ButtonLink;
  return /* @__PURE__ */ jsx(ButtonWrapper, { $align: align, children: /* @__PURE__ */ jsxs(
    ButtonComponent,
    {
      href: !asButton ? link : void 0,
      target,
      onClick: asButton ? onClick : void 0,
      ...rest,
      $variant: variant,
      children: [
        showIcon && /* @__PURE__ */ jsx(Icon, { iconData: "arrowRight", alt: "arrow icon" }),
        children
      ]
    }
  ) });
};

export { Button as B, Container as C, Icon as I };
