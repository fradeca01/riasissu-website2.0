import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import 'react/jsx-runtime';
import 'react';
import { P as Piazza, $ as $$Layout } from './Layout_DkimS7Iu.mjs';
import { H as Hero } from './index_DwWahPK4.mjs';

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content"> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "fullPageSlider", "data": [
    {
      title: "XCOOL 2025",
      subtitle: 'Udine 3-6 Settembre 2025, Scuola Superiore " Di Toppo Wassermann"',
      background: Piazza.src,
      paragraph: "Per ulteriori informazioni, contattaci a xcool@riasissu.it.",
      button: {
        text: "Scarica il regolamento",
        // link : "/xcool/formclosed",
        link: "https://docs.google.com/document/d/1s-zJGsPYkalBX8bdJcWRafC1iemn5NLFNGzwRJaZEg4/edit?usp=sharing"
      },
      secondaryButton: {
        text: "Programma dell'evento",
        link: "/xcool/info"
        // link : "/xcool/formclosed",
      },
      tertiaryButton: {
        text: "Iscriviti alla RIASISSU!",
        link: "http://bit.ly/iscrizione_soci"
        // link : "/xcool/formclosed",
      }
    }
  ], "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero" })} </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/index.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/index.astro";
const $$url = "/xcool";

export { $$Index as default, $$file as file, $$url as url };
