import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { C as ContentSection } from './index_zExVMqt0.mjs';
import { $ as $$Layout } from './Layout_B_oYnPBF.mjs';
import { F as FadeIn, B as Button } from './index_BNki1cO2.mjs';

const $$Formclosed = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Form Closed", "description": "The form you want to access is closed at the moment." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content page-404"> ${renderComponent($$result2, "ContentSection", ContentSection, { "style": {
    maxWidth: "600px",
    margin: "0 auto",
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    height: "100%"
  } }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:visible": true, "client:component-hydration": "visible", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn" }, { "default": ($$result4) => renderTemplate` <h1>Le iscrizioni sono chiuse!</h1> <p>
Le iscrizioni alle XCool apriranno a breve e chiuderanno il
                    15 Maggio. maggio.
</p> ${renderComponent($$result4, "Button", Button, { "variant": "secondary", "showIcon": false, "link": "/xcool/", "align": "center" }, { "default": ($$result5) => renderTemplate`
Torna indietro
` })} ` })} ` })} </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/formclosed.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/formclosed.astro";
const $$url = "/xcool/formclosed";

export { $$Formclosed as default, $$file as file, $$url as url };
