import { b as createAstro, c as createComponent, r as renderTemplate, d as addAttribute, m as maybeRenderHead, a as renderComponent } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout } from './Layout_DkimS7Iu.mjs';
import 'clsx';
/* empty css                               */

const sport_urls = [
  "xcool_tennis",
  "xcool_quadriglia",
  "xcool_pallavolo",
  "xcool_scacchi_blitz",
  "xcool_scacchi_rapid",
  "xcool_pingpong",
  "xcool_padel",
  "xcool_calcio_maschile",
  "xcool_calcio_femminile",
  "xcool_beachvolley",
  "xcool_basket",
  "xcool_dibattito",
  "xcool_biliardino"
];
const url_to_title = {
  "xcool_tennis": "Tennis",
  "xcool_quadriglia": "Scacchi - Quadriglia",
  "xcool_pallavolo": "Pallavolo",
  "xcool_scacchi_blitz": "Scacchi - Blitz",
  "xcool_scacchi_rapid": "Scacchi - Rapid",
  "xcool_pingpong": "Tennistavolo",
  "xcool_padel": "Padel",
  "xcool_calcio_maschile": "Calcio a 5 Maschile",
  "xcool_calcio_femminile": "Calcio a 5 Femminile",
  "xcool_beachvolley": "Beach Volley",
  "xcool_basket": "Basket",
  "xcool_dibattito": "Dibattito Competitivo",
  "xcool_biliardino": "Biliardino"
};
const url_to_height = {
  "xcool_tennis": 700,
  "xcool_quadriglia": 1100,
  "xcool_pallavolo": 1500,
  "xcool_scacchi_blitz": 1e3,
  "xcool_scacchi_rapid": 1e3,
  "xcool_pingpong": 3e3,
  "xcool_padel": 1050,
  "xcool_calcio_maschile": 1e3,
  "xcool_calcio_femminile": 550,
  "xcool_beachvolley": 5400,
  "xcool_basket": 800,
  "xcool_dibattito": 600,
  "xcool_biliardino": 5200
};

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro$1 = createAstro("https://riasissu.it");
const $$IFrameWithProgress = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$IFrameWithProgress;
  const { src, title = "Embedded content", height = 600, width, class: klass = "", frameborder, allowtransparency, scrolling } = Astro2.props;
  return renderTemplate(_a || (_a = __template(["", "<div", "", ' data-astro-cid-ttr75gzi> <div class="loadbar" id="bar" data-astro-cid-ttr75gzi></div> <iframe class="iframe-el"', "", "", "", "", "", ` loading="lazy" referrerpolicy="no-referrer-when-downgrade" data-astro-cid-ttr75gzi></iframe> </div> <script>
  // Lightweight "NProgress-style" bar: creeps to 95% until iframe fires 'load'
  const wrap = document.currentScript.previousElementSibling;
  const bar  = wrap.querySelector('#bar');
  const frame = wrap.querySelector('iframe');

  let prog = 0;
  let rafId;
  let startTime = performance.now();
  const MIN_SHOW_MS = 350; // avoid flicker on instant loads

  function tick() {
    // Ease towards 95% while loading
    const target = 0.95;
    const delta = (target - prog) * 0.08; // easing factor
    prog += delta;
    if (prog > target) prog = target;
    bar.style.transform = \`scaleX(\${prog})\`;
    rafId = requestAnimationFrame(tick);
  }

  function finish(ok = true) {
    const done = () => {
      cancelAnimationFrame(rafId);
      prog = 1;
      bar.style.transform = 'scaleX(1)';
      wrap.classList.toggle('error', !ok);
      // allow paint, then fade bar + reveal iframe
      requestAnimationFrame(() => wrap.classList.add('loaded'));
    };

    const elapsed = performance.now() - startTime;
    if (elapsed < MIN_SHOW_MS) {
      setTimeout(done, MIN_SHOW_MS - elapsed);
    } else {
      done();
    }
  }

  // Start animating when the iframe enters viewport (saves some jank)
  const io = new IntersectionObserver(entries => {
    if (entries.some(e => e.isIntersecting)) {
      io.disconnect();
      tick();
      // In case 'load' fired from cache before IO started
      if (frame.complete) finish(true);
    }
  }, { rootMargin: '200px' });
  io.observe(frame);

  frame.addEventListener('load', () => finish(true), { once: true });
  frame.addEventListener('error', () => finish(false), { once: true });

  // Safety timeout: if 'load' never fires (rare), complete after 20s
  setTimeout(() => {
    if (!wrap.classList.contains('loaded')) finish(false);
  }, 20000);
<\/script>`], ["", "<div", "", ' data-astro-cid-ttr75gzi> <div class="loadbar" id="bar" data-astro-cid-ttr75gzi></div> <iframe class="iframe-el"', "", "", "", "", "", ` loading="lazy" referrerpolicy="no-referrer-when-downgrade" data-astro-cid-ttr75gzi></iframe> </div> <script>
  // Lightweight "NProgress-style" bar: creeps to 95% until iframe fires 'load'
  const wrap = document.currentScript.previousElementSibling;
  const bar  = wrap.querySelector('#bar');
  const frame = wrap.querySelector('iframe');

  let prog = 0;
  let rafId;
  let startTime = performance.now();
  const MIN_SHOW_MS = 350; // avoid flicker on instant loads

  function tick() {
    // Ease towards 95% while loading
    const target = 0.95;
    const delta = (target - prog) * 0.08; // easing factor
    prog += delta;
    if (prog > target) prog = target;
    bar.style.transform = \\\`scaleX(\\\${prog})\\\`;
    rafId = requestAnimationFrame(tick);
  }

  function finish(ok = true) {
    const done = () => {
      cancelAnimationFrame(rafId);
      prog = 1;
      bar.style.transform = 'scaleX(1)';
      wrap.classList.toggle('error', !ok);
      // allow paint, then fade bar + reveal iframe
      requestAnimationFrame(() => wrap.classList.add('loaded'));
    };

    const elapsed = performance.now() - startTime;
    if (elapsed < MIN_SHOW_MS) {
      setTimeout(done, MIN_SHOW_MS - elapsed);
    } else {
      done();
    }
  }

  // Start animating when the iframe enters viewport (saves some jank)
  const io = new IntersectionObserver(entries => {
    if (entries.some(e => e.isIntersecting)) {
      io.disconnect();
      tick();
      // In case 'load' fired from cache before IO started
      if (frame.complete) finish(true);
    }
  }, { rootMargin: '200px' });
  io.observe(frame);

  frame.addEventListener('load', () => finish(true), { once: true });
  frame.addEventListener('error', () => finish(false), { once: true });

  // Safety timeout: if 'load' never fires (rare), complete after 20s
  setTimeout(() => {
    if (!wrap.classList.contains('loaded')) finish(false);
  }, 20000);
<\/script>`])), maybeRenderHead(), addAttribute(`iframe-wrap ${klass}`, "class"), addAttribute(`--h:${typeof height === "number" ? `${height}px` : height};`, "style"), addAttribute(src, "src"), addAttribute(title, "title"), addAttribute(width, "width"), addAttribute(frameborder, "frameborder"), addAttribute(allowtransparency, "allowtransparency"), addAttribute(scrolling, "scrolling"));
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/components/IFrameWithProgress/IFrameWithProgress.astro", void 0);

const $$Astro = createAstro("https://riasissu.it");
async function getStaticPaths() {
  return sport_urls.map((sport_url) => ({
    params: { sport_url }
  }));
}
const $$sportUrl = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$sportUrl;
  const { sport_url } = Astro2.params;
  const frameSrc = `https://challonge.com/${sport_url}/module`;
  const finalHeight = url_to_height[sport_url] + "px";
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:150px;margin-bottom:50px;">${url_to_title[sport_url]}</h1></center> <div style="overflow:auto"> ${renderComponent($$result2, "IframeWithProgress", $$IFrameWithProgress, { "src": frameSrc, "width": "100%", "height": finalHeight, "frameborder": "0", "scrolling": "auto", "allowtransparency": "true" })} </div> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/calendario/[sport_url].astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/calendario/[sport_url].astro";
const $$url = "/xcool/calendario/[sport_url]";

export { $$sportUrl as default, $$file as file, getStaticPaths, $$url as url };
