import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import styled from '@emotion/styled';
import { T as Theme, M as MediaQuery, $ as $$Layout } from './Layout_DYG7mY7p.mjs';
import { F as FadeIn } from './FadeIn_T1S2RvbP.mjs';

const medals = new Proxy({"src":"/xcool/_astro/medals.UJ-vpkB_.webp","width":3438,"height":1209,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/medals.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/medals.webp");
							return target[name];
						}
					});

const tennis = new Proxy({"src":"/xcool/_astro/tennis.DIaUFq7G.webp","width":1280,"height":720,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/tennis.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/tennis.webp");
							return target[name];
						}
					});

const chess = new Proxy({"src":"/xcool/_astro/chess.hO3H6no6.webp","width":400,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/chess.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/chess.webp");
							return target[name];
						}
					});

const pingpong = new Proxy({"src":"/xcool/_astro/pingpong.D_QnpbGZ.webp","width":449,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pingpong.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pingpong.webp");
							return target[name];
						}
					});

const padel = new Proxy({"src":"/xcool/_astro/padel.BLzSu1XT.webp","width":749,"height":500,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/padel.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/padel.webp");
							return target[name];
						}
					});

const volley = new Proxy({"src":"/xcool/_astro/pallavolo.CrmPCldw.webp","width":922,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pallavolo.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pallavolo.webp");
							return target[name];
						}
					});

const chiosco = new Proxy({"src":"/xcool/_astro/chiosco.DUkaSAW5.webp","width":612,"height":408,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/chiosco.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/chiosco.webp");
							return target[name];
						}
					});

const calcio = new Proxy({"src":"/xcool/_astro/calcio.IuwuZTP8.webp","width":450,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/calcio.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/calcio.webp");
							return target[name];
						}
					});

const beachvolley = new Proxy({"src":"/xcool/_astro/beachvolley.0hk5WDF0.webp","width":400,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/beachvolley.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/beachvolley.webp");
							return target[name];
						}
					});

const biliardino = new Proxy({"src":"/xcool/_astro/biliardino.DqaF_tno.webp","width":400,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/biliardino.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/biliardino.webp");
							return target[name];
						}
					});

const dibattito = new Proxy({"src":"/xcool/_astro/Debate.CsX0WeEx.webp","width":475,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/Debate.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/Debate.webp");
							return target[name];
						}
					});

const basket = new Proxy({"src":"/xcool/_astro/basket.CmHphmvV.webp","width":2462,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/basket.webp";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/basket.webp");
							return target[name];
						}
					});

const cards = [
  {
    href: "/xcool/tabelloni/xcool_tennis",
    imgSrc: tennis.src,
    title: "Tennis",
    format: "Torneo a eliminazione diretta.",
    participants: "8 squadre"
  },
  {
    href: "/xcool/tabelloni/xcool_quadriglia",
    imgSrc: chess.src,
    title: "Scacchi - Quadriglia",
    format: "Torneo svizzero a 6 round.",
    participants: "7 squadre"
  },
  {
    href: "/xcool/tabelloni/xcool_scacchi_blitz",
    imgSrc: chess.src,
    title: "Scacchi - Rapid",
    format: "Torneo svizzero a 6 round.",
    participants: "TBD"
  },
  {
    href: "/xcool/tabelloni/xcool_scacchi_rapid",
    imgSrc: chess.src,
    title: "Scacchi - Blitz",
    format: "Torneo svizzero a 6 round.",
    participants: "TBD"
  },
  {
    href: "/xcool/tabelloni/xcool_pingpong",
    imgSrc: pingpong.src,
    title: "Tennistavolo",
    format: "Gironi (6 -> 1), poi eliminazione diretta.",
    participants: "48 giocatori."
  },
  {
    href: "/xcool/tabelloni/xcool_padel",
    imgSrc: padel.src,
    title: "Padel",
    format: "Torneo a eliminazione diretta.",
    participants: "19 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_pallavolo",
    imgSrc: volley.src,
    title: "Pallavolo",
    format: "Gironi (4 -> 2), poi eliminazione diretta.",
    participants: "13 squadre."
  },
  {
    href: "/xcool/tabelloni/coppa_chiosco",
    imgSrc: chiosco.src,
    title: "Coppa Chiosco",
    format: "Bevi più che puoi!",
    participants: "11 scuole."
  },
  {
    href: "/xcool/tabelloni/xcool_calcio_maschile",
    imgSrc: calcio.src,
    title: "Calcio a 5 Maschile",
    format: "Gironi (5 -> 4), poi eliminazione diretta.",
    participants: "10 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_calcio_femminile",
    imgSrc: calcio.src,
    title: "Calcio a 5 Femminile",
    format: "Gironi (3 -> 2), poi eliminazione diretta.",
    participants: "3 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_beachvolley",
    imgSrc: beachvolley.src,
    title: "Beach Volley",
    format: "Gironi (3 -> 1), poi eliminazione diretta.",
    participants: "36 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_basket",
    imgSrc: basket.src,
    title: "Basket",
    format: "Gironi (3 -> 2), poi eliminazione diretta.",
    participants: "6 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_dibattito",
    imgSrc: dibattito.src,
    title: "Dibattito Competitivo",
    format: "Torneo all'italiana.",
    participants: "3 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_biliardino",
    imgSrc: biliardino.src,
    title: "Biliardino",
    format: "Gironi (4->1), poi eliminazione diretta.",
    participants: "48 squadre."
  }
  // ...add as many as you like
];

({
  href: "/xcool/dashboard/medals",
  imgSrc: medals.src,
  title: "Medagliere",
  description: "Visualizza la classifica delle medaglie."
});
const PageWrapper = styled.div`
  padding: 40px;
  background: ${Theme.secondary};
`;
const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 24px;

  ${MediaQuery.max("md")} {
    grid-template-columns: 1fr;
  }
`;
const CardLink = styled.a`
  display: block;
  text-decoration: none;
  color: inherit;
  border-radius: 12px;
  overflow: hidden;
  max-width: 875px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
  border-color: #94a3b87d;
  border-style: solid;
  border-width: 0.5px;
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.15);
  }
`;
const CardImage = styled.img`
  width: 100%;
  height: 160px;
  object-fit: cover;
`;
const CardContent = styled.div`
  padding: 16px;
  background: ${Theme.secondary};
`;
const CardTitle = styled.h3`
  margin: 0 0 8px;
  font-size: 20px;
  line-height: 1.2;
  color: ${Theme.primary};
`;
const CardDescription = styled.div`
  margin: 2px;
  font-size: 14px;
  color: #cbcacd;
`;
styled.h2`
margin-top:200px;
`;
const CardGallery = () => /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(PageWrapper, { children: /* @__PURE__ */ jsx(Grid, { children: cards.map((c) => {
  const priority = c.title == "Tennis" ? "high" : "auto";
  return /* @__PURE__ */ jsxs(CardLink, { href: c.href, children: [
    /* @__PURE__ */ jsx(CardImage, { src: c.imgSrc, alt: c.title, fetchPriority: priority }),
    /* @__PURE__ */ jsxs(CardContent, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: c.title }),
      /* @__PURE__ */ jsxs(CardDescription, { children: [
        /* @__PURE__ */ jsx("strong", { children: "Formato: " }),
        c.format
      ] }),
      /* @__PURE__ */ jsxs(CardDescription, { children: [
        /* @__PURE__ */ jsx("strong", { children: "Partecipanti: " }),
        c.participants
      ] })
    ] })
  ] }, c.href);
}) }) }) });

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center> <h1 class="page-title" style="margin-top: 200px;">
Gironi e Tabelloni
</h1> <div style="color:#94A3B8;">
Sport presenti alle XCool con relativo tabellone. <a class="link" href="/xcool/info">Clicca qui</a> per vedere calendario, programma ed altre informazioni!
</div> </center> ${renderComponent($$result2, "CardGallery", CardGallery, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/home/runner/work/xcool-webpage/xcool-webpage/src/components/Card/CardGallery", "client:component-export": "default" })} </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/index.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/index.astro";
const $$url = "/xcool/tabelloni";

export { $$Index as default, $$file as file, $$url as url };
