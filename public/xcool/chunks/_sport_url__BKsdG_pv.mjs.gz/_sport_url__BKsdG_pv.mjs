import { b as createAstro, c as createComponent, r as renderTemplate, d as addAttribute, m as maybeRenderHead, a as renderComponent } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout } from './Layout_Dlc8nqxQ.mjs';
import 'clsx';
/* empty css                               */

const sport_urls = [
  "xcool_tennis",
  "xcool_quadriglia",
  "xcool_pallavolo",
  "xcool_scacchi_blitz",
  "xcool_scacchi_rapid",
  "xcool_pingpong",
  "xcool_padel",
  "xcool_calcio_maschile",
  "xcool_calcio_femminile",
  "xcool_beachvolley",
  "xcool_basket",
  "xcool_dibattito",
  "xcool_biliardino"
];
const url_to_title = {
  "xcool_tennis": "Tennis",
  "xcool_quadriglia": "Scacchi - Quadriglia",
  "xcool_pallavolo": "Pallavolo",
  "xcool_scacchi_blitz": "Scacchi - Blitz",
  "xcool_scacchi_rapid": "Scacchi - Rapid",
  "xcool_pingpong": "Tennistavolo",
  "xcool_padel": "Padel",
  "xcool_calcio_maschile": "Calcio a 5 Maschile",
  "xcool_calcio_femminile": "Calcio a 5 Femminile",
  "xcool_beachvolley": "Beach Volley",
  "xcool_basket": "Basket",
  "xcool_dibattito": "Dibattito Competitivo",
  "xcool_biliardino": "Biliardino"
};
const url_to_height = {
  "xcool_tennis": 750,
  "xcool_quadriglia": 1100,
  "xcool_pallavolo": 1600,
  "xcool_scacchi_blitz": 1e3,
  "xcool_scacchi_rapid": 1e3,
  "xcool_pingpong": 3e3,
  "xcool_padel": 1050,
  "xcool_calcio_maschile": 1100,
  "xcool_calcio_femminile": 550,
  "xcool_beachvolley": 6e3,
  "xcool_basket": 900,
  "xcool_dibattito": 600,
  "xcool_biliardino": 5900
};

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro$1 = createAstro("https://riasissu.it");
const $$IFrameWithProgress = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$IFrameWithProgress;
  const { src, title = "Embedded content", height = 600, width, class: klass = "", frameborder, allowtransparency, scrolling } = Astro2.props;
  return renderTemplate(_a || (_a = __template(["", "<div", "", ' data-astro-cid-ttr75gzi> <div class="loadbar" id="bar" data-astro-cid-ttr75gzi></div> <center data-astro-cid-ttr75gzi><iframe class="iframe-el"', "", "", "", "", "", "", " loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\" data-astro-cid-ttr75gzi></iframe></center> </div> <script>\n    const wrap = document.currentScript.previousElementSibling;\n    const bar   = wrap.querySelector('.loadbar');\n    const frame = wrap.querySelector('iframe');\n\n    // Config\n    const STOP1 = 0.60;      // first stop (60%)\n    const STOP2 = 0.95;      // second stop (95%)\n    const EASE  = 0.08;      // easing factor for approach\n    const PAUSE_AT_60_MS = 600; // how long to hold at 60% before moving toward 95%\n    const MIN_SHOW_MS = 350; // avoid flicker on ultra-fast loads\n\n    // State\n    let prog = 0;\n    let phase = 1;     // 1: approach 60, 2: hold 60, 3: approach 95, 4: waiting for load to finish()\n    let t60 = null;    // timestamp when we reached 60%\n    let rafId;\n    const startTime = performance.now();\n\n    function tick() {\n      let target;\n      if (phase === 1) target = STOP1;         // move up to 60%\n      else if (phase === 2) target = STOP1;    // hold at 60%\n      else target = STOP2;                     // move up to 95%\n\n      // Only animate when not in a \"hard hold\"\n      if (phase !== 2) {\n        const delta = (target - prog) * EASE;\n        prog += delta;\n        // snap when close\n        if (Math.abs(target - prog) < 0.002) prog = target;\n        bar.style.transform = `scaleX(${prog})`;\n      }\n\n      // Phase transitions\n      if (phase === 1 && prog >= STOP1 - 0.001) {\n        phase = 2;                 // reached 60%\n        t60 = performance.now();   // start hold timer\n        bar.style.transform = `scaleX(${STOP1})`;\n      } else if (phase === 2) {\n        // after the pause, if still not loaded, proceed toward 95%\n        if (performance.now() - t60 >= PAUSE_AT_60_MS) {\n          phase = 3;\n        }\n      } else if (phase === 3) {\n        // once we hit 95, stop advancing; wait for load to finish\n        if (prog >= STOP2 - 0.001) {\n          prog = STOP2;\n          bar.style.transform = `scaleX(${STOP2})`;\n          phase = 4; // idle until finish()\n        }\n      }\n\n      rafId = requestAnimationFrame(tick);\n    }\n\n    function finish(ok = true) {\n      const done = () => {\n        cancelAnimationFrame(rafId);\n        prog = 1;\n        bar.style.transform = 'scaleX(1)';\n        wrap.classList.toggle('error', !ok);\n        requestAnimationFrame(() => wrap.classList.add('loaded'));\n      };\n      const elapsed = performance.now() - startTime;\n      elapsed < MIN_SHOW_MS ? setTimeout(done, MIN_SHOW_MS - elapsed) : done();\n    }\n\n    // Start when in view\n    const io = new IntersectionObserver(entries => {\n      if (entries.some(e => e.isIntersecting)) {\n        io.disconnect();\n        tick();\n        // if already loaded from cache\n        if (frame.complete) finish(true);\n      }\n    }, { rootMargin: '200px' });\n    io.observe(frame);\n\n    frame.addEventListener('load',  () => finish(true),  { once: true });\n    frame.addEventListener('error', () => finish(false), { once: true });\n\n    // Safety: give up after 20s if nothing fires\n    setTimeout(() => {\n      if (!wrap.classList.contains('loaded')) finish(false);\n    }, 20000);\n  \n<\/script>"], ["", "<div", "", ' data-astro-cid-ttr75gzi> <div class="loadbar" id="bar" data-astro-cid-ttr75gzi></div> <center data-astro-cid-ttr75gzi><iframe class="iframe-el"', "", "", "", "", "", "", " loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\" data-astro-cid-ttr75gzi></iframe></center> </div> <script>\n    const wrap = document.currentScript.previousElementSibling;\n    const bar   = wrap.querySelector('.loadbar');\n    const frame = wrap.querySelector('iframe');\n\n    // Config\n    const STOP1 = 0.60;      // first stop (60%)\n    const STOP2 = 0.95;      // second stop (95%)\n    const EASE  = 0.08;      // easing factor for approach\n    const PAUSE_AT_60_MS = 600; // how long to hold at 60% before moving toward 95%\n    const MIN_SHOW_MS = 350; // avoid flicker on ultra-fast loads\n\n    // State\n    let prog = 0;\n    let phase = 1;     // 1: approach 60, 2: hold 60, 3: approach 95, 4: waiting for load to finish()\n    let t60 = null;    // timestamp when we reached 60%\n    let rafId;\n    const startTime = performance.now();\n\n    function tick() {\n      let target;\n      if (phase === 1) target = STOP1;         // move up to 60%\n      else if (phase === 2) target = STOP1;    // hold at 60%\n      else target = STOP2;                     // move up to 95%\n\n      // Only animate when not in a \"hard hold\"\n      if (phase !== 2) {\n        const delta = (target - prog) * EASE;\n        prog += delta;\n        // snap when close\n        if (Math.abs(target - prog) < 0.002) prog = target;\n        bar.style.transform = \\`scaleX(\\${prog})\\`;\n      }\n\n      // Phase transitions\n      if (phase === 1 && prog >= STOP1 - 0.001) {\n        phase = 2;                 // reached 60%\n        t60 = performance.now();   // start hold timer\n        bar.style.transform = \\`scaleX(\\${STOP1})\\`;\n      } else if (phase === 2) {\n        // after the pause, if still not loaded, proceed toward 95%\n        if (performance.now() - t60 >= PAUSE_AT_60_MS) {\n          phase = 3;\n        }\n      } else if (phase === 3) {\n        // once we hit 95, stop advancing; wait for load to finish\n        if (prog >= STOP2 - 0.001) {\n          prog = STOP2;\n          bar.style.transform = \\`scaleX(\\${STOP2})\\`;\n          phase = 4; // idle until finish()\n        }\n      }\n\n      rafId = requestAnimationFrame(tick);\n    }\n\n    function finish(ok = true) {\n      const done = () => {\n        cancelAnimationFrame(rafId);\n        prog = 1;\n        bar.style.transform = 'scaleX(1)';\n        wrap.classList.toggle('error', !ok);\n        requestAnimationFrame(() => wrap.classList.add('loaded'));\n      };\n      const elapsed = performance.now() - startTime;\n      elapsed < MIN_SHOW_MS ? setTimeout(done, MIN_SHOW_MS - elapsed) : done();\n    }\n\n    // Start when in view\n    const io = new IntersectionObserver(entries => {\n      if (entries.some(e => e.isIntersecting)) {\n        io.disconnect();\n        tick();\n        // if already loaded from cache\n        if (frame.complete) finish(true);\n      }\n    }, { rootMargin: '200px' });\n    io.observe(frame);\n\n    frame.addEventListener('load',  () => finish(true),  { once: true });\n    frame.addEventListener('error', () => finish(false), { once: true });\n\n    // Safety: give up after 20s if nothing fires\n    setTimeout(() => {\n      if (!wrap.classList.contains('loaded')) finish(false);\n    }, 20000);\n  \n<\/script>"])), maybeRenderHead(), addAttribute(`iframe-wrap ${klass}`, "class"), addAttribute(`--h:${typeof height === "number" ? `${height}px` : height};`, "style"), addAttribute(src, "src"), addAttribute(title, "title"), addAttribute(height, "height"), addAttribute(width, "width"), addAttribute(frameborder, "frameborder"), addAttribute(allowtransparency, "allowtransparency"), addAttribute(scrolling, "scrolling"));
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/components/IFrameWithProgress/IFrameWithProgress.astro", void 0);

const $$Astro = createAstro("https://riasissu.it");
async function getStaticPaths() {
  return sport_urls.map((sport_url) => ({
    params: { sport_url }
  }));
}
const $$sportUrl = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$sportUrl;
  const { sport_url } = Astro2.params;
  const frameSrc = `https://challonge.com/${sport_url}/module`;
  const finalHeight = url_to_height[sport_url] + "px";
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:150px;margin-bottom:50px;">${url_to_title[sport_url]}</h1></center> <div style="overflow:auto"> ${renderComponent($$result2, "IframeWithProgress", $$IFrameWithProgress, { "src": frameSrc, "width": "98%", "height": finalHeight, "frameborder": "0", "scrolling": "auto", "allowtransparency": "true" })} </div> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/[sport_url].astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/[sport_url].astro";
const $$url = "/xcool/tabelloni/[sport_url]";

export { $$sportUrl as default, $$file as file, getStaticPaths, $$url as url };
