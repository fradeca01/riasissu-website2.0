import { b as createAstro, c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead, d as addAttribute } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout } from './Layout_DkimS7Iu.mjs';

const sport_urls = [
  "xcool_tennis",
  "xcool_quadriglia",
  "xcool_pallavolo",
  "xcool_scacchi_blitz",
  "xcool_scacchi_rapid",
  "xcool_pingpong",
  "xcool_padel",
  "xcool_calcio_maschile",
  "xcool_calcio_femminile",
  "xcool_beachvolley",
  "xcool_basket",
  "xcool_dibattito",
  "xcool_biliardino"
];
const url_to_title = {
  "xcool_tennis": "Tennis",
  "xcool_quadriglia": "Scacchi - Quadriglia",
  "xcool_pallavolo": "Pallavolo",
  "xcool_scacchi_blitz": "Scacchi - Blitz",
  "xcool_scacchi_rapid": "Scacchi - Rapid",
  "xcool_pingpong": "Tennistavolo",
  "xcool_padel": "Padel",
  "xcool_calcio_maschile": "Calcio a 5 Maschile",
  "xcool_calcio_femminile": "Calcio a 5 Femminile",
  "xcool_beachvolley": "Beach Volley",
  "xcool_basket": "Basket",
  "xcool_dibattito": "Dibattito Competitivo",
  "xcool_biliardino": "Biliardino"
};

const $$Astro = createAstro("https://riasissu.it");
async function getStaticPaths() {
  return sport_urls.map((sport_url) => ({
    params: { sport_url }
  }));
}
const $$sportUrl = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$sportUrl;
  const { sport_url } = Astro2.params;
  const svgUrl = `https://challonge.com/${sport_url}.svg`;
  const frameSrc = `https://challonge.com/${sport_url}/module`;
  const targetWidth = 800;
  const res = await fetch(svgUrl);
  const svgText = await res.text();
  const match = svgText.match(/<svg[^>]*>/i);
  let svgHeight = 0;
  if (match) {
    const svgTag = match[0];
    const heightAttr = svgTag.match(/\bheight\s*=\s*["']([^"']+)["']/i)?.[1];
    const viewBoxAttr = svgTag.match(/\bviewBox\s*=\s*["']([^"']+)["']/i)?.[1];
    if (heightAttr) {
      svgHeight = parseFloat(heightAttr);
    } else if (viewBoxAttr) {
      const parts = viewBoxAttr.split(/[\s,]+/).map(Number);
      if (parts.length === 4 && !parts.some(isNaN)) {
        const [, , vbWidth, vbHeight] = parts;
        svgHeight = vbHeight / vbWidth * targetWidth;
      }
    }
  }
  const finalHeight = svgHeight * 1.6 + "px";
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:150px;margin-bottom:50px;">${url_to_title[sport_url]}</h1></center> <div style="overflow:auto"> <iframe${addAttribute(frameSrc, "src")} width="100%"${addAttribute(finalHeight, "height")} frameborder="0" scrolling="auto" allowtransparency="true"></iframe> </div> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/calendario/[sport_url].astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/calendario/[sport_url].astro";
const $$url = "/xcool/calendario/[sport_url]";

export { $$sportUrl as default, $$file as file, getStaticPaths, $$url as url };
