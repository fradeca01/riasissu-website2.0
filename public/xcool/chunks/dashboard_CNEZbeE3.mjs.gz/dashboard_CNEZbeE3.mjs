import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsxs, jsx } from 'react/jsx-runtime';
import 'react';
import styled from '@emotion/styled';
import { T as Theme, M as MediaQuery, $ as $$Layout } from './Layout_B_oYnPBF.mjs';

const cards = [
  {
    href: "https://challonge.com/it/xcool_tennis/module",
    imgSrc: "/src/assets/tennis.jpg",
    title: "Tennis",
    format: "Torneo a singola eliminazione.",
    participants: "8 squadre"
  },
  {
    href: "https://challonge.com/it/xcool_quadriglia/module",
    imgSrc: "/src/assets/chess.jpeg",
    title: "Scacchi - Quadriglia",
    format: "Torneo svizzero a 6 round.",
    participants: "7 squadre"
  },
  {
    href: "https://challonge.com/it/xcool_scacchi_blitz/module",
    imgSrc: "/src/assets/chess.jpeg",
    title: "Scacchi - Rapid",
    format: "Torneo svizzero a 6 round.",
    participants: "TBD"
  },
  {
    href: "https://challonge.com/it/xcool_scacchi_rapid/module",
    imgSrc: "/src/assets/chess.jpeg",
    title: "Scacchi - Blitz",
    format: "Torneo svizzero a 6 round.",
    participants: "TBD"
  },
  {
    href: "https://challonge.com/it/xcool_pingpong/module",
    imgSrc: "/src/assets/pingpong.jpg",
    title: "Tennis Tavolo",
    format: "Gironi (6 -> 1), poi eliminazione diretta.",
    participants: "48 giocatori."
  },
  {
    href: "https://challonge.com/it/xcool_padel/module",
    imgSrc: "/src/assets/padel.jpeg",
    title: "Padel",
    format: "Eliminazione diretta.",
    participants: "19 squadre."
  },
  {
    href: "https://challonge.com/it/xcool_pallavolo/module",
    imgSrc: "/src/assets/pallavolo.jpg",
    title: "Pallavolo",
    format: "Gironi (4 -> 2), poi eliminazione diretta.",
    participants: "13 squadre."
  },
  {
    href: "/xcool/coppa_chiosco",
    imgSrc: "/src/assets/chiosco.jpeg",
    title: "Coppa Chiosco",
    format: "Bevi più che puoi!",
    participants: "11 scuole."
  }
  // ...add as many as you like
];

const medalTable = {
  href: "/xcool/medals",
  imgSrc: "/src/assets/medals.png",
  title: "Medagliere",
  description: "Visualizza la classifica delle medaglie."
};
const PageWrapper = styled.div`
  padding: 40px;
  background: ${Theme.secondary};
`;
const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 24px;

  ${MediaQuery.max("md")} {
    grid-template-columns: 1fr;
  }
`;
const CardLink = styled.a`
  display: block;
  text-decoration: none;
  color: inherit;
  border-radius: 12px;
  overflow: hidden;
  max-width: 875px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
  border-color: #94a3b87d;
  border-style: solid;
  border-width: 0.5px;
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.15);
  }
`;
const CardImage = styled.img`
  width: 100%;
  height: 160px;
  object-fit: cover;
`;
const CardContent = styled.div`
  padding: 16px;
  background: ${Theme.secondary};
`;
const CardTitle = styled.h3`
  margin: 0 0 8px;
  font-size: 20px;
  line-height: 1.2;
  color: ${Theme.primary};
`;
const CardDescription = styled.div`
  margin: 10px;
  font-size: 14px;
  color: #94a3b8;
`;
const CardGallery = () => /* @__PURE__ */ jsxs(PageWrapper, { children: [
  /* @__PURE__ */ jsx("center", { children: /* @__PURE__ */ jsxs(CardLink, { href: medalTable.href, children: [
    /* @__PURE__ */ jsx(CardImage, { src: medalTable.imgSrc, alt: medalTable.title }),
    /* @__PURE__ */ jsxs(CardContent, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: medalTable.title }),
      /* @__PURE__ */ jsx(CardDescription, { children: medalTable.description })
    ] })
  ] }, medalTable.href) }),
  /* @__PURE__ */ jsx("br", {}),
  /* @__PURE__ */ jsx("br", {}),
  /* @__PURE__ */ jsx("center", { children: /* @__PURE__ */ jsx("h2", { children: "Tornei" }) }),
  /* @__PURE__ */ jsx("br", {}),
  /* @__PURE__ */ jsx("br", {}),
  /* @__PURE__ */ jsx(Grid, { children: cards.map((c) => /* @__PURE__ */ jsxs(CardLink, { href: c.href, children: [
    /* @__PURE__ */ jsx(CardImage, { src: c.imgSrc, alt: c.title }),
    /* @__PURE__ */ jsxs(CardContent, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: c.title }),
      /* @__PURE__ */ jsxs(CardDescription, { children: [
        /* @__PURE__ */ jsx("strong", { children: "Formato: " }),
        c.format
      ] }),
      /* @__PURE__ */ jsxs(CardDescription, { children: [
        /* @__PURE__ */ jsx("strong", { children: "Partecipanti: " }),
        c.participants
      ] })
    ] })
  ] }, c.href)) })
] });

const $$Dashboard = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center> <h1 class="page-title" style="margin-top: 200px;">Dashboard</h1> <div style="color:#94A3B8;">Sport presenti alle xcool con relativo tabellone.</div> </center> ${renderComponent($$result2, "CardGallery", CardGallery, { "client:load": true, "client:component-hydration": "load", "client:component-path": "/home/runner/work/xcool-webpage/xcool-webpage/src/components/Card/CardGallery", "client:component-export": "default" })} </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/dashboard.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/dashboard.astro";
const $$url = "/xcool/dashboard";

export { $$Dashboard as default, $$file as file, $$url as url };
