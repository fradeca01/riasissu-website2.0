import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { H as Hero } from './index_CmhEquZc.mjs';
import { F as FadeIn, B as Button, $ as $$Layout } from './index_Bw1phOco.mjs';
import { C as ContentSection } from './index_CUjD9vWd.mjs';
/* empty css                        */

const $$Info = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg", "data-astro-cid-34s7mdjv": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page" data-astro-cid-34s7mdjv> ${renderComponent($$result2, "Hero", Hero, { "client:load": true, "heroType": "ParallaxImage", "data": {
    content: {
      title: "Programma XCOOL 2025",
      paragraph: "Qua potrai trovare tutte le informazioni utili riguardanti le XCOOL 2025. Tutte le novit\xE0, gli aggiornamenti e le informazioni utili verranno pubblicate in questa pagina."
    }
  }, "client:component-hydration": "load", "client:component-path": "@modules/Hero", "client:component-export": "Hero", "data-astro-cid-34s7mdjv": true })} ${renderComponent($$result2, "ContentSection", ContentSection, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@modules/ContentSection", "client:component-export": "ContentSection", "data-astro-cid-34s7mdjv": true }, { "default": ($$result3) => renderTemplate` ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn", "data-astro-cid-34s7mdjv": true }, { "default": ($$result4) => renderTemplate` <div class="row" data-astro-cid-34s7mdjv> <div class="sidebar" data-astro-cid-34s7mdjv> <div class="sticky" data-astro-cid-34s7mdjv> <h1 data-astro-cid-34s7mdjv>Le Squadre</h1><h4 data-astro-cid-34s7mdjv>
Squadre iscritte all'evento
</h4> </div> </div> <div class="side-content" data-astro-cid-34s7mdjv> <p data-astro-cid-34s7mdjv>
Al link qui sotto è possibile visualizzare l'elenco
                            di tutte le squadre iscritte all'evento XCOOL 2025.
                            Le squadre sono divise per sport:
</p> <div class="button-container" data-astro-cid-34s7mdjv> ${renderComponent($$result4, "Button", Button, { "variant": "primary", "showIcon": true, "target": "_blank", "link": "https://docs.google.com/document/d/1BKdfkffQc8etiyxV_l39QZ6VS3RYNrPKlK8FbAHZREo/edit?usp=sharing", "data-astro-cid-34s7mdjv": true }, { "default": ($$result5) => renderTemplate`
SQUADRE ISCRITTE
` })} </div> <p data-astro-cid-34s7mdjv>
Dopo la conclusione delle iscrizioni, sono state
                            effettuate varie modifiche e aggiunte alle squadre.
                            Per questo motivo, è possibile che alcune squadre
                            siano differenti rispetto a quelle inizialmente
                            iscritte. In particolare, in alcuni casi, sono state
                            create squadre miste. Per qualsiasi dubbio o
                            necessità, contattare il referente dello sport
                            oppure inviare una mail a:
<a href="mailto://xcool@riasissu.it" data-astro-cid-34s7mdjv>xcool@riasissu.it</a>.
</p> </div> </div> ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn", "data-astro-cid-34s7mdjv": true }, { "default": ($$result4) => renderTemplate` <div class="row" data-astro-cid-34s7mdjv> <div class="sidebar" data-astro-cid-34s7mdjv> <div class="sticky" data-astro-cid-34s7mdjv> <h1 data-astro-cid-34s7mdjv>I Luoghi</h1><h4 data-astro-cid-34s7mdjv>Posizioni utili</h4> </div> </div> <div class="side-content" data-astro-cid-34s7mdjv> <p data-astro-cid-34s7mdjv>
Al seguente link è possibile trovare una mappa con i
                            luoghi dove si svolgeranno le gare e le attività
                            dell'evento XCOOL 2025. La mappa include anche i
                            punti di interesse come ristoranti bar consigliati,
                            oltre ad altri servizi utili per i partecipanti:
</p> <p data-astro-cid-34s7mdjv>
nelle note potete trovare maggiori informazioni per
                            ogni segnalino!
</p> <div class="button-container" data-astro-cid-34s7mdjv> ${renderComponent($$result4, "Button", Button, { "variant": "primary", "showIcon": true, "target": "_blank", "link": "https://maps.app.goo.gl/kZZEk3YP4zzxH19G7", "data-astro-cid-34s7mdjv": true }, { "default": ($$result5) => renderTemplate`
Mappa posizioni utili
` })} </div> </div> </div> ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn", "data-astro-cid-34s7mdjv": true }, { "default": ($$result4) => renderTemplate` <div class="row" data-astro-cid-34s7mdjv> <div class="sidebar" data-astro-cid-34s7mdjv> <div class="sticky" data-astro-cid-34s7mdjv> <h1 data-astro-cid-34s7mdjv>Gli Alloggi</h1><h4 data-astro-cid-34s7mdjv>Distribuzione alloggi</h4> </div> </div> <div class="side-content" data-astro-cid-34s7mdjv> <p data-astro-cid-34s7mdjv>
Nel documento sottostante è possibile visualizzare
                            l'elenco degli alloggi e la distribuzione dei
                            partecipanti. Gli alloggi sono stati organizzati in
                            base alle disponibilità di strutture
</p> <ul data-astro-cid-34s7mdjv> <li data-astro-cid-34s7mdjv>
Tutti gli alloggi sono <strong data-astro-cid-34s7mdjv>prenotati per 4 notti, dal 3 al 6 settembre
                                    2025 (notti del 3,4,5,6 settembre)</strong> </li> <li data-astro-cid-34s7mdjv> <strong data-astro-cid-34s7mdjv>NON è possibile ritirarsi dall'evento</strong>, in quanto la vostra presenza è stata
                                garantita alle strutture (salvo, certamente,
                                casi di comprovata necessità).
</li> <li data-astro-cid-34s7mdjv>
Tutti i prezzi sono calcolati <strong data-astro-cid-34s7mdjv>PER PERSONA A NOTTE</strong>.
</li> <li data-astro-cid-34s7mdjv>
la Scuola Superiore di Udine ha prenotato gli
                                alloggi nelle strutture: quanto a <strong data-astro-cid-34s7mdjv>pagamento</strong>, <strong data-astro-cid-34s7mdjv>fatture</strong>
e <strong data-astro-cid-34s7mdjv>rimborsi</strong> vi muoverete in <strong data-astro-cid-34s7mdjv>autonomia</strong> in base a come preferisce la vostra Scuola. Potrete
                                quindi:
<ul data-astro-cid-34s7mdjv> <li data-astro-cid-34s7mdjv>
già contattare la struttura e saldare il
                                        conto (eventualmente anche 1 bonifico
                                        per Scuola)
</li> <li data-astro-cid-34s7mdjv>
saldare il conto quando soggiornerete a
                                        Udine, quindi dal 3 al 6 settembre 2025.
</li> </ul> </li> <li data-astro-cid-34s7mdjv>
Nel contattare le strutture con colazione,
                                avvisate NUOVAMENTE PER <strong data-astro-cid-34s7mdjv>INTOLLERANZE E/O ALLERGIE</strong>.
</li> </ul> <div class="button-container" style="margin-bottom: 0rem;" data-astro-cid-34s7mdjv> ${renderComponent($$result4, "Button", Button, { "variant": "primary", "showIcon": true, "target": "_blank", "link": "https://docs.google.com/spreadsheets/d/1s-zJGsPYkalBX8bdJcWRafC1iemn5NLFNGzwRJaZEg4/edit?usp=sharing", "data-astro-cid-34s7mdjv": true }, { "default": ($$result5) => renderTemplate`
Distribuzione alloggi
` })} </div> </div> </div> ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn", "data-astro-cid-34s7mdjv": true }, { "default": ($$result4) => renderTemplate` <div class="scroll-animation row" data-astro-cid-34s7mdjv> <div class="sidebar" data-astro-cid-34s7mdjv> <div class="sticky" data-astro-cid-34s7mdjv> <h1 data-astro-cid-34s7mdjv>Calendario</h1><h4 data-astro-cid-34s7mdjv>Calendario dell'evento</h4> </div> </div> <div class="side-content" data-astro-cid-34s7mdjv> <p style="font-style: oblique;" data-astro-cid-34s7mdjv>COMING SOON...</p> </div> </div> ` })} ${renderComponent($$result3, "FadeIn", FadeIn, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@utils/animations/FadeIn", "client:component-export": "FadeIn", "data-astro-cid-34s7mdjv": true }, { "default": ($$result4) => renderTemplate` <div class="row" data-astro-cid-34s7mdjv> <div class="sidebar" data-astro-cid-34s7mdjv> <div class="sticky" data-astro-cid-34s7mdjv> <h1 data-astro-cid-34s7mdjv>Contatti</h1> </div> </div> <div class="side-content contatti" data-astro-cid-34s7mdjv> <p data-astro-cid-34s7mdjv>Per qualunque dubbio o domanda contattarci a:</p> <p data-astro-cid-34s7mdjv></p><ul data-astro-cid-34s7mdjv> <li data-astro-cid-34s7mdjv> <a href="mailto://xcool@riasissu.it" data-astro-cid-34s7mdjv>xcool@riasissu.it</a> </li> <li data-astro-cid-34s7mdjv> <a href="mailto://maddalena.feltrin@riasissu.it" data-astro-cid-34s7mdjv>maddalena.feltrin@riasissu.it</a> </li> <li data-astro-cid-34s7mdjv> <a href="mailto://francesco.decataldo@riasissu.it" data-astro-cid-34s7mdjv>francesco.decataldo@riasissu.it</a> </li> <li data-astro-cid-34s7mdjv> <a href="mailto://niccolo.gaspari@riasissu.it" data-astro-cid-34s7mdjv>niccolo.gaspari@riasissu.it</a> </li> </ul>  </div> </div> ` })} ` })} <!-- <ServiceCards
                title="Scegli il servizio che ti interessa"
                client:visible
                cards={[
                    {
                        title: "Visualizza iscrizioni",
                        description:
                            "lorem ipsum lorem ipsum lorem ipsum lorem ipsum .",
                    },
                    {
                        title: "Visualizza squadre",
                        description:
                            "lorem ipsum lorem ipsum lorem ipsum lorem ipsum .",
                    },
                ]}
            /> --> </main> ` })} `;
}, "/media/Data/Universita/RIASISSU/WebSite/xcool/src/pages/info.astro", void 0);

const $$file = "/media/Data/Universita/RIASISSU/WebSite/xcool/src/pages/info.astro";
const $$url = "/xcool/info";

export { $$Info as default, $$file as file, $$url as url };
