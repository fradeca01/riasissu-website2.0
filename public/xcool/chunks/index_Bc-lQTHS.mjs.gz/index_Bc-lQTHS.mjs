import { jsxs, jsx } from 'react/jsx-runtime';
import { useState } from 'react';
import styled from '@emotion/styled';
import { T as Theme, M as MediaQuery } from './Layout_DtNL3mso.mjs';
import { css } from '@emotion/react';

const InputBoxStyled = styled.div`
    padding: 20px;
    border-radius: 10px;
    background: ${Theme.primary};
    box-shadow: 0 0 10px rgb(123 123 123 / 30%);
    display: flex;
    align-items: center;
    height: 100%;
    width: 70%;
    color: ${Theme.secondary};
    border-radius: 15px;
    position: relative;

    ${(props) => props.$variant === "background-text" && InputBoxBackgroundTextVariant};
`;
const InputBoxLinkStyled = InputBoxStyled.withComponent("a");
const InputBoxBgText = styled.span`
    position: absolute;
    top: 0;
    right: 0;
    text-transform: uppercase;
    font-size: 80px;
    line-height: 1;
    font-weight: 900;
    letter-spacing: -5px;
    z-index: 1;
    color: ${Theme.primary};
    opacity: 0.5;

    ${MediaQuery.max("xxl")} {
        font-size: 70px;
    }

    ${MediaQuery.max("xl")} {
        font-size: 50px;
        letter-spacing: -3px;
    }
`;
const InputBoxWrapper = styled.div`
    position: relative;
    z-index: 2;
    width: 100%;
`;
const InputBoxInput = styled.input`
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: none;
    outline: none;
    background: transparent;
    color: ${Theme.secondary};

    &::placeholder {
        color: ${Theme.tertiary};
        opacity: 0.7;
    }
`;
const InputBoxBackgroundTextVariant = css`
    position: relative;
    overflow: hidden;
    padding: 20px;

    input {
        position: relative;
        z-index: 2;
        font-size: 18px;
    }
`;

const InputBox = ({
  value,
  onChange,
  placeholder,
  variant,
  bgText,
  type,
  boxAsLink,
  href,
  target
}) => {
  const InputBoxComponent = boxAsLink ? InputBoxLinkStyled : InputBoxStyled;
  useState("");
  return /* @__PURE__ */ jsxs(InputBoxComponent, { $variant: variant, href, target, children: [
    variant === "background-text" && bgText && /* @__PURE__ */ jsx(InputBoxBgText, { children: bgText }),
    /* @__PURE__ */ jsx(InputBoxWrapper, { children: /* @__PURE__ */ jsx(
      InputBoxInput,
      {
        type,
        value,
        onChange,
        placeholder
      }
    ) })
  ] });
};

export { InputBox as I };
