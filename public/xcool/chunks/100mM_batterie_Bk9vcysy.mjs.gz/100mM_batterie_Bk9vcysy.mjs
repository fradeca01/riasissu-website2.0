const data1 = [
  {
    athlete: "Francesco Peroni",
    school: "SGSS",
    lane: 5,
    time: "10.05",
    qualifier: "Q"
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Simone Fisichella",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Giovanni Marzioni",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Santi Fisichella",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    time: ""
  }
];
const data2 = [
  {
    athlete: "Nazareno Piccin",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Giulio De Musso",
    school: "ISUFI",
    time: ""
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Cairone",
    school: "???",
    time: ""
  }
];
const data3 = [
  {
    athlete: "Gioele Clemente",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Lorenzo Ciaffi",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Lorenzo Montano",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Tommaso Malpensa",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: ""
  }
];
const data4 = [
  {
    athlete: "Filippo Troina",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Gabriele B. Finocchiaro",
    //Bartolomeo
    school: "SSC",
    time: ""
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Francesco Decataldo",
    school: "SSDTW",
    time: ""
  }
];

export { data1, data2, data3, data4 };
