import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { M as MediaQuery, $ as $$Layout } from './Layout_B_oYnPBF.mjs';
import { jsxs, Fragment, jsx } from 'react/jsx-runtime';
import { useState, useEffect } from 'react';
import { I as InputBox } from './index_CxiM1Q2u.mjs';
import { H as Hero } from './index_CFg0soiP.mjs';
import { C as ContentSection } from './index_zExVMqt0.mjs';
import { F as FadeIn, B as Button } from './index_BNki1cO2.mjs';
import styled from '@emotion/styled';
import { keyframes } from '@emotion/react';

const spin = keyframes`
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
`;
const Spinner = styled.div`
  border: 4px solid #f3f3f3;
  border-top: 4px solid #29d;
  border-radius: 50%;
  width: 30px;
  height: 30px;
  animation: ${spin} 0.8s linear infinite;
  margin: 20px auto;
`;
const authorizedStyled = styled.div`                
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items:center;
        // overflow: hidden;
        height: 100%;
        h2, h3, h4 {
            margin-bottom: 10px;
            font-size: 20px;
            line-height: 2;
        }

        p {
            margin-top: 20px;
            }

        ${MediaQuery.max("md")} {

        p  {
            margin-top: 10px;
            }


        }`;
styled.div`
        text-align: center;
        display: flex;
        justify-content: center;
        flex-direction: row;
        align-items: center;
        gap:50px;

        ${MediaQuery.max("md")} {
            flex-direction: column;
            gap: 0px;
        }`;

const ProtectedInfo = ({}) => {
  const url = "https://us-central1-riasissu-7c453.cloudfunctions.net/passwordProtectedPage?password=";
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [authorized, setAuthorized] = useState(false);
  useEffect(() => {
    const saved = localStorage.getItem("authorized");
    if (saved === "true") {
      setAuthorized(true);
    }
  });
  const handleSubmit = async () => {
    if (!text.trim())
      return;
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `${url}${text}`,
        { method: "GET", mode: "cors", credentials: "omit" }
      );
      if (!response.ok) {
        throw new Error("Password errata.");
      }
      const data = await response.json();
      if (data.redirectUrl) {
        setAuthorized(true);
        localStorage.setItem("authorized", "true");
      } else {
        setError("Errore: nessun URL ricevuto.");
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Errore sconosciuto";
      setError(errorMessage || "Errore di connessione.");
    } finally {
      setLoading(false);
    }
  };
  if (authorized) {
    return /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx("style", { children: `
    .button-container {
        margin-bottom: 3rem;
        width: 100%;
        display: flex;
        justify-content: center;
    }

    .row {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 1.5rem;

        margin: 100px auto;

        /* padding: 0 50px; */

        @media (min-width: 768px) {
            grid-template-columns: repeat(8, minmax(0, 1fr));
            padding: 0 50px;
        }
        @media (min-width: 1024px) {
            grid-template-columns: repeat(12, minmax(0, 1fr));
        }
    }

    .sidebar {
        grid-column: span 4 / span 4;

        @media (min-width: 1024px) {
            grid-column: span 3 / span 3;
        }
    }

    .side-content {
        grid-column: span 4 / span 4;
        display: flex;
        flex-direction: column;
        align-items: left;
        justify-content: center;

        @media (min-width: 1024px) {
            grid-column: span 9 / span 9;
        }
    }

    .sticky {
        width: 100%;
    }

    h4 {
        margin-bottom: 0px;
        font-size: 1.5rem;
    }

    @media (min-width: 1024px) {
        .sticky {
            position: sticky;
            top: 10rem;

            h1,
            h2,
            h3,
            h4 {
                text-align: left;
            }

            p {
                font-size: 1.2rem;
            }
        }
    }

    h1 {
        color: white;
        text-align: center;
        font-size: 2rem;
        margin-bottom: 0.3rem;
    }

    li {
        text-align: left;
    }

    @media (min-width: 768px) {
        .contatti li {
            font-size: 1.2rem;
        }
    }
    /* .contatti li {
        font-size: 1.2rem;
    } */

    li a,
    p a {
        color: #abdbe3;
    }
        ` }),
      /* @__PURE__ */ jsx(
        Hero,
        {
          heroType: "ParallaxImage",
          data: {
            content: {
              title: "Programma XCOOL 2025",
              paragraph: "Qua potrai trovare tutte le informazioni utili riguardanti le XCOOL 2025. Tutte le novità, gli aggiornamenti e le informazioni utili verranno pubblicate in questa pagina."
            }
          }
        }
      ),
      /* @__PURE__ */ jsxs(ContentSection, { children: [
        /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsx("div", { className: "sidebar", children: /* @__PURE__ */ jsxs("div", { className: "sticky", children: [
            /* @__PURE__ */ jsx("h1", { children: "Le Squadre" }),
            /* @__PURE__ */ jsx("h4", { children: "Squadre iscritte all'evento" })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "side-content", children: [
            /* @__PURE__ */ jsx("p", { children: "Al link qui sotto è possibile visualizzare l'elenco di tutte le squadre iscritte all'evento XCOOL 2025. Le squadre sono divise per sport:" }),
            /* @__PURE__ */ jsx("div", { className: "button-container", children: /* @__PURE__ */ jsx(
              Button,
              {
                variant: "primary",
                showIcon: true,
                target: "_blank",
                link: "https://docs.google.com/document/d/1BKdfkffQc8etiyxV_l39QZ6VS3RYNrPKlK8FbAHZREo/edit?usp=sharing",
                children: "SQUADRE ISCRITTE"
              }
            ) }),
            /* @__PURE__ */ jsxs("p", { children: [
              "Dopo la conclusione delle iscrizioni, sono state effettuate varie modifiche e aggiunte alle squadre. Per questo motivo, è possibile che alcune squadre siano differenti rispetto a quelle inizialmente iscritte. In particolare, in alcuni casi, sono state create squadre miste. Per qualsiasi dubbio o necessità, contattare il referente dello sport oppure inviare una mail a:",
              /* @__PURE__ */ jsx("a", { href: "mailto://xcool@riasissu.it", children: "xcool@riasissu.it" }),
              "."
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsx("div", { className: "sidebar", children: /* @__PURE__ */ jsxs("div", { className: "sticky", children: [
            /* @__PURE__ */ jsx("h1", { children: "I Luoghi" }),
            /* @__PURE__ */ jsx("h4", { children: "Posizioni utili" })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "side-content", children: [
            /* @__PURE__ */ jsx("p", { children: "Al seguente link è possibile trovare una mappa con i luoghi dove si svolgeranno le gare e le attività dell'evento XCOOL 2025. La mappa include anche i punti di interesse come ristoranti bar consigliati, oltre ad altri servizi utili per i partecipanti:" }),
            /* @__PURE__ */ jsx("p", { children: "nelle note potete trovare maggiori informazioni per ogni segnalino!" }),
            /* @__PURE__ */ jsx("div", { className: "button-container", children: /* @__PURE__ */ jsx(
              Button,
              {
                variant: "primary",
                showIcon: true,
                target: "_blank",
                link: "https://maps.app.goo.gl/kZZEk3YP4zzxH19G7",
                children: "Mappa posizioni utili"
              }
            ) })
          ] })
        ] }) }),
        /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsx("div", { className: "sidebar", children: /* @__PURE__ */ jsxs("div", { className: "sticky", children: [
            /* @__PURE__ */ jsx("h1", { children: "Gli Alloggi" }),
            /* @__PURE__ */ jsx("h4", { children: "Distribuzione alloggi" })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "side-content", children: [
            /* @__PURE__ */ jsx("p", { children: "Nel documento sottostante è possibile visualizzare l'elenco degli alloggi e la distribuzione dei partecipanti. Gli alloggi sono stati organizzati in base alle disponibilità di strutture" }),
            /* @__PURE__ */ jsxs("ul", { children: [
              /* @__PURE__ */ jsxs("li", { children: [
                "Tutti gli alloggi sono ",
                /* @__PURE__ */ jsx(
                  "strong",
                  {
                    children: "prenotati per 4 notti, dal 3 al 6 settembre 2025 (notti del 3,4,5,6 settembre)"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                /* @__PURE__ */ jsx("strong", { children: "NON è possibile ritirarsi dall'evento" }),
                ", in quanto la vostra presenza è stata garantita alle strutture (salvo, certamente, casi di comprovata necessità)."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Tutti i prezzi sono calcolati ",
                /* @__PURE__ */ jsx(
                  "strong",
                  {
                    children: "PER PERSONA A NOTTE"
                  }
                ),
                "."
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "la Scuola Superiore di Udine ha prenotato gli alloggi nelle strutture: quanto a ",
                /* @__PURE__ */ jsx("strong", { children: "pagamento" }),
                ", ",
                /* @__PURE__ */ jsx(
                  "strong",
                  {
                    children: "fatture"
                  }
                ),
                "e ",
                /* @__PURE__ */ jsx("strong", { children: "rimborsi" }),
                " vi muoverete in ",
                /* @__PURE__ */ jsx(
                  "strong",
                  {
                    children: "autonomia"
                  }
                ),
                " in base a come preferisce la vostra Scuola. Potrete quindi:",
                /* @__PURE__ */ jsxs("ul", { children: [
                  /* @__PURE__ */ jsx("li", { children: "già contattare la struttura e saldare il conto (eventualmente anche 1 bonifico per Scuola)" }),
                  /* @__PURE__ */ jsx("li", { children: "saldare il conto quando soggiornerete a Udine, quindi dal 3 al 6 settembre 2025." })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("li", { children: [
                "Nel contattare le strutture con colazione, avvisate NUOVAMENTE PER ",
                /* @__PURE__ */ jsx("strong", { children: "INTOLLERANZE E/O ALLERGIE" }),
                "."
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "button-container", style: {
              marginBottom: "0rem"
            }, children: /* @__PURE__ */ jsx(
              Button,
              {
                variant: "primary",
                showIcon: true,
                target: "_blank",
                link: "https://docs.google.com/document/d/1QIerLjX8iBiLPjpeGLLW4YB5w5vjbWdmav9xsiccpfI/edit?usp=sharing",
                children: "Distribuzione alloggi"
              }
            ) })
          ] })
        ] }) }),
        /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs("div", { className: "scroll-animation row", children: [
          /* @__PURE__ */ jsx("div", { className: "sidebar", children: /* @__PURE__ */ jsxs("div", { className: "sticky", children: [
            /* @__PURE__ */ jsx("h1", { children: "Calendario" }),
            /* @__PURE__ */ jsx("h4", { children: "Calendario dell'evento" })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "side-content", children: [
            /* @__PURE__ */ jsxs("p", { children: [
              "L'innaugurazione dell'evento avrà luogo il ",
              /* @__PURE__ */ jsx(
                "strong",
                {
                  children: "3 Settembre alle 17:00"
                }
              ),
              " alla ",
              /* @__PURE__ */ jsx("strong", { children: "Loggia del Lionello" }),
              " in centro a ",
              /* @__PURE__ */ jsx("strong", { children: "Udine" }),
              "."
            ] }),
            /* @__PURE__ */ jsxs("p", { children: [
              "L'evento si concluderà la notte del ",
              /* @__PURE__ */ jsx(
                "strong",
                {
                  children: "6 Settembre"
                }
              ),
              "."
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs("div", { className: "scroll-animation row", children: [
          /* @__PURE__ */ jsx("div", { className: "sidebar", children: /* @__PURE__ */ jsxs("div", { className: "sticky", children: [
            /* @__PURE__ */ jsx("h1", { children: "Nuova Competizione" }),
            /* @__PURE__ */ jsx("h4", { children: "Competizione ADMO" })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "side-content", children: [
            /* @__PURE__ */ jsxs("p", { children: [
              "In collaborazione con ",
              /* @__PURE__ */ jsx("strong", { children: "ADMO" }),
              ", Associazione Donatori Midollo Osseo, verrà istituita una coppa che premerierà la Scuola più virtuosa, ossia con maggiori iscritti al ",
              /* @__PURE__ */ jsx("strong", { children: "registro nazionale (IBMDR)" }),
              "!"
            ] }),
            /* @__PURE__ */ jsxs("p", { children: [
              "Infatti, durante la cerimonia di inaugurazione verrà presentata l’attività di ",
              /* @__PURE__ */ jsx("strong", { children: "ADMO" }),
              " e, durante tutte le giornate delle ",
              /* @__PURE__ */ jsx("strong", { children: "XCool" }),
              ", sarà possibile tipizzarsi e così iscriversi!"
            ] }),
            /* @__PURE__ */ jsx(
              Button,
              {
                variant: "primary",
                showIcon: true,
                target: "_blank",
                link: "/xcool/ADMOXCOOL.pdf",
                children: "Scarica qua la locandina"
              }
            )
          ] })
        ] }) }),
        /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs("div", { className: "row", children: [
          /* @__PURE__ */ jsx("div", { className: "sidebar", children: /* @__PURE__ */ jsx("div", { className: "sticky", children: /* @__PURE__ */ jsx("h1", { children: "Contatti" }) }) }),
          /* @__PURE__ */ jsxs("div", { className: "side-content contatti", children: [
            /* @__PURE__ */ jsx("p", { children: "Per qualunque dubbio o domanda contattarci a:" }),
            /* @__PURE__ */ jsx("p", { children: /* @__PURE__ */ jsxs("ul", { children: [
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href: "mailto://xcool@riasissu.it",
                  children: "xcool@riasissu.it"
                }
              ) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href: "mailto://maddalena.feltrin@riasissu.it",
                  children: "maddalena.feltrin@riasissu.it"
                }
              ) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href: "mailto://francesco.decataldo@riasissu.it",
                  children: "francesco.decataldo@riasissu.it"
                }
              ) }),
              /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(
                "a",
                {
                  href: "mailto://niccolo.gaspari@riasissu.it",
                  children: "niccolo.gaspari@riasissu.it"
                }
              ) })
            ] }) })
          ] })
        ] }) })
      ] })
    ] });
  } else {
    return /* @__PURE__ */ jsxs(authorizedStyled, { children: [
      /* @__PURE__ */ jsx("h6", { children: "L'accesso ai dati è riservato ai partecipanti Xcool 2025. Chiedi la password al tuo rappresentante." }),
      /* @__PURE__ */ jsx("p", { children: "Inserisci la password:" }),
      /* @__PURE__ */ jsx("br", {}),
      /* @__PURE__ */ jsx(
        InputBox,
        {
          value: text,
          onChange: (e) => setText(e.target.value),
          placeholder: "Enter password...",
          type: "password"
        }
      ),
      error && /* @__PURE__ */ jsx("p", { style: { color: "red" }, children: error }),
      loading && /* @__PURE__ */ jsx(Spinner, {}),
      /* @__PURE__ */ jsx(
        Button,
        {
          variant: "secondary",
          showIcon: false,
          asButton: true,
          target: "_blank",
          type: "button",
          onClick: handleSubmit,
          align: "center",
          children: loading ? "Verifica..." : "Vai alle info!"
        }
      )
    ] });
  }
};

const $$Info = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> ${renderComponent($$result2, "ProtectedInfo", ProtectedInfo, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@components/ProtectedInfo", "client:component-export": "ProtectedInfo" })} </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/info.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/info.astro";
const $$url = "/xcool/info";

export { $$Info as default, $$file as file, $$url as url };
