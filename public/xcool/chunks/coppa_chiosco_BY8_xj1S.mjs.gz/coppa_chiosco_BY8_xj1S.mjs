import { c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsx, jsxs } from 'react/jsx-runtime';
import { useState, useEffect } from 'react';
import styled from '@emotion/styled';
import { T as Theme, $ as $$Layout } from './Layout_CvPEZ8T4.mjs';

const ChartWrapper = styled.div`
    margin-top: 50px;
  width: 100%;
  padding: 24px;
  background: ${Theme.secondary};
  border-radius: 12px;
  max-width: 960px;
  align-self: center;
`;
const Row = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 16px;
`;
const Label = styled.div`
  flex: 0 0 80px;
  font-size: 14px;
  font-weight: 600;
  color: ${Theme.primary};
  margin-right: 12px;
`;
const BarContainer = styled.div`
  flex: 1;
  background: ${Theme.secondary};
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  height: 20px;
`;
const Bar = styled.div`
  width: ${({ pct }) => pct}%;
  background: #0000FF;
  height: 100%;
  border-radius: 12px 12px 12px 12px;
  transition: width 1s ease-out;
`;
const Value = styled.div`
  position: absolute;
  left: ${({ pct }) => pct}%;
  top: 50%;
  transform: translate(${({ pct }) => pct > 90 ? "-100%,-50%" : "4px,-50%"});
  transition: left 1s ease-out, transform 1s ease-out;
  font-size: 16px;
  font-weight: 500;
  color: ${Theme.primary};
  white-space: nowrap;
  
`;
function BarChart({ data }) {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const id = window.setTimeout(() => setLoaded(true), 50);
    return () => window.clearTimeout(id);
  }, []);
  const max = Math.max(...data.map((d) => d.total), 1);
  return /* @__PURE__ */ jsx(ChartWrapper, { children: data.map((d) => {
    const pct = Math.round(d.total / max * 90);
    const displayPct = loaded ? pct : 0;
    return /* @__PURE__ */ jsxs(Row, { children: [
      /* @__PURE__ */ jsx(Label, { children: d.school }),
      /* @__PURE__ */ jsxs(BarContainer, { children: [
        /* @__PURE__ */ jsx(Bar, { pct: displayPct }),
        /* @__PURE__ */ jsxs(Value, { pct: displayPct, children: [
          d.total,
          " ",
          /* @__PURE__ */ jsx("img", { width: "18px", src: "/src/assets/beer.png" })
        ] })
      ] })
    ] }, d.school);
  }) });
}

const totals = [
  { school: "SSC", total: 5 },
  { school: "CSB", total: 7 },
  { school: "SSSUP", total: 2 },
  { school: "IUSS", total: 10 },
  { school: "ISUFI", total: 23 },
  { school: "SSAS", total: 4 },
  { school: "SGSS", total: 3 },
  { school: "SSDTW", total: 9 },
  { school: "SSST", total: 12 },
  { school: "SSMC", total: 17 },
  { school: "CAM", total: 19 }
];

const $$CoppaChiosco = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025 - Medals", "description": "Medal standings for the XCOOL 2025 event." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:200px;">Coppa Chiosco</h1></center> ${renderComponent($$result2, "BarChart", BarChart, { "client:load": true, "data": totals, "client:component-hydration": "load", "client:component-path": "/home/runner/work/xcool-webpage/xcool-webpage/src/components/DrinkBarChart/DrinkBarChart", "client:component-export": "default" })} </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/coppa_chiosco.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/coppa_chiosco.astro";
const $$url = "/xcool/coppa_chiosco";

export { $$CoppaChiosco as default, $$file as file, $$url as url };
