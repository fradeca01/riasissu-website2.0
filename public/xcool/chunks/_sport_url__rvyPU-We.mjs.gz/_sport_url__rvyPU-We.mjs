import { b as createAstro, c as createComponent, r as renderTemplate, a as renderComponent, m as maybeRenderHead, d as addAttribute } from './astro/server_BgKBZDYX.mjs';
import 'kleur/colors';
import 'html-escaper';
import { $ as $$Layout } from './Layout_DYc9pYHw.mjs';

const sport_urls = [
  "xcool_tennis",
  "xcool_quadriglia",
  "xcool_pallavolo",
  "xcool_scacchi_blitz",
  "xcool_scacchi_rapid",
  "xcool_pingpong",
  "xcool_padel",
  "xcool_calcio_maschile",
  "xcool_calcio_femminile",
  "xcool_beachvolley",
  "xcool_basket",
  "xcool_dibattito",
  "xcool_biliardino"
];
const url_to_title = {
  "xcool_tennis": "Tennis",
  "xcool_quadriglia": "Scacchi - Quadriglia",
  "xcool_pallavolo": "Pallavolo",
  "xcool_scacchi_blitz": "Scacchi - Blitz",
  "xcool_scacchi_rapid": "Scacchi - Rapid",
  "xcool_pingpong": "Tennistavolo",
  "xcool_padel": "Padel",
  "xcool_calcio_maschile": "Calcio a 5 Maschile",
  "xcool_calcio_femminile": "Calcio a 5 Femminile",
  "xcool_beachvolley": "Beach Volley",
  "xcool_basket": "Basket",
  "xcool_dibattito": "Dibattito Competitivo",
  "xcool_biliardino": "Biliardino"
};

const $$Astro = createAstro("https://riasissu.it");
async function getStaticPaths() {
  return sport_urls.map((sport_url) => ({
    params: { sport_url }
  }));
}
const $$sportUrl = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$sportUrl;
  const { sport_url } = Astro2.params;
  const imgSrc = `https://challonge.com/it/${sport_url}.svg`;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:150px;">${url_to_title[sport_url]}</h1></center> <div style="overflow:auto;"> <center> <img style="clip-path: inset(100px 0 0 0);"${addAttribute(imgSrc, "src")} max-width="90%"></center> </div> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tornei/[sport_url].astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tornei/[sport_url].astro";
const $$url = "/xcool/tornei/[sport_url]";

export { $$sportUrl as default, $$file as file, getStaticPaths, $$url as url };
