import { jsx, jsxs } from 'react/jsx-runtime';
import styled from '@emotion/styled';
import { M as MediaQuery, F as FadeInStyled, T as Theme } from './Layout_DkimS7Iu.mjs';
import { useRef, useEffect } from 'react';
import { css } from '@emotion/react';

const StyledContainer = styled.div`
    margin: 0 auto;
    padding: 0 50px;
    width: 100%;

    // max-width: 540px;

    ${MediaQuery.between("md", "lg")} {
        // max-width: 720px;
    }

    ${MediaQuery.between("lg", "xl")} {
        // max-width: 960px;
    }

    ${MediaQuery.between("xl", "xxl")} {
        // max-width: 1140px;
    }

    ${MediaQuery.min("xxl")} {
        // max-width: 1320px;
    }
`;

const Container = ({ children, ...rest }) => {
  if (!children) {
    return null;
  }
  return /* @__PURE__ */ jsx(StyledContainer, { ...rest, children });
};

const convertToSeconds = (delay) => {
  return Number(delay) * 1e3;
};
const FadeIn = ({ children, delay }) => {
  const elementRef = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add("visible");
            }, convertToSeconds(delay ? delay : 0));
          }
        });
      },
      {
        root: null,
        rootMargin: "-50px",
        threshold: 0.1
      }
    );
    if (elementRef.current) {
      observer.observe(elementRef.current);
    }
    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, []);
  return /* @__PURE__ */ jsx(FadeInStyled, { ref: elementRef, children });
};

const IconArrowDown = new Proxy({"src":"/xcool/_astro/icon-arrow-down.BDCzw7Ed.svg","width":30,"height":30,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-arrow-down.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-arrow-down.svg");
							return target[name];
						}
					});

const IconArrowCircle = new Proxy({"src":"/xcool/_astro/icon-arrow-circle.DUoOPlmj.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-arrow-circle.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-arrow-circle.svg");
							return target[name];
						}
					});

const IconArrowRight = new Proxy({"src":"/xcool/_astro/icon-arrow-right.DqPTpFau.svg","width":20,"height":20,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-arrow-right.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-arrow-right.svg");
							return target[name];
						}
					});

const IconFacebook = new Proxy({"src":"/xcool/_astro/icon-facebook.CiZt8951.svg","width":15,"height":32,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-facebook.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-facebook.svg");
							return target[name];
						}
					});

const IconInstagram = new Proxy({"src":"/xcool/_astro/icon-instagram.BWvvhaKh.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-instagram.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-instagram.svg");
							return target[name];
						}
					});

const IconTwitter = new Proxy({"src":"/xcool/_astro/icon-twitter.-eebusCm.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-twitter.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-twitter.svg");
							return target[name];
						}
					});

const IconLinkedIn = new Proxy({"src":"/xcool/_astro/icon-linkedin.Cr8d3BTd.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-linkedin.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-linkedin.svg");
							return target[name];
						}
					});

const IconGithub = new Proxy({"src":"/xcool/_astro/icon-github.DH9R7T2y.svg","width":50,"height":50,"format":"svg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-github.svg";
							}
							if (target[name] !== undefined) globalThis.astroAsset.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/icon-github.svg");
							return target[name];
						}
					});

const icons = {
  arrowDown: IconArrowDown,
  arrowCircle: IconArrowCircle,
  arrowRight: IconArrowRight,
  facebook: IconFacebook,
  instagram: IconInstagram,
  twitter: IconTwitter,
  linkedin: IconLinkedIn,
  github: IconGithub
};
const Icon = ({ alt, iconData, ...rest }) => {
  const icon = icons[iconData];
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: icon.src,
      alt,
      width: icon.width,
      height: icon.height,
      "data-icon": "true",
      ...rest
    }
  );
};

const ButtonWrapper = styled.div`
    display: flex;
    justify-content: ${({ $align }) => $align || "flex-start"};
    margin-top: 20px;
`;
const ButtonLink = styled.a`
    text-transform: uppercase;
    transition: 0.3s;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    text-align: center;
    position: relative;
    z-index: 2;

    ${({ $variant }) => $variant === "primary" && PrimaryVariant};
    ${({ $variant }) => $variant === "secondary" && SecondaryVariant};
`;
const Button$1 = ButtonLink.withComponent("button");
const PrimaryVariant = css`
    display: inline-flex;
    align-items: center;
    font-size: 25px;
    line-height: 30px;
    padding: 10px;
    margin-top: 40px;
    transition: color 0.5s;
    transition-delay: 0.2s;

    ${MediaQuery.max("lg")} {
        font-size: 20px;
        line-height: 18px;
        margin-top: 20px;
    }

    &:before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 0%;
        background: ${Theme.primary};
        z-index: -1;
        transition: width 0.5s;
    }

    &:after {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 1px;
        background: ${Theme.primary};
        transition: width 0.5s;
    }

    &:hover {
        color: ${Theme.secondary};

        &:before {
            width: 100%;
        }

        &:after {
            width: 0%;
        }

        img {
            margin-right: 30px;
            opacity: 1;
        }
    }

    img {
        transition-delay: 0.2s;
        filter: invert(1);
        opacity: 0;
        margin-right: -20px;
        transition: all 0.5s;
    }
`;
const SecondaryVariant = css`
    padding: 12px 40px;
    min-width: 150px;
    border: 1.5px solid ${Theme.tertiary};
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1px;
    font-weight: 500;
    border-radius: 50px;
    background: ${Theme.tertiary};
    color: ${Theme.primary};

    &:hover {
        background: transparent;
        color: ${Theme.secondary};
    }
`;

const Button = ({
  link,
  target,
  children,
  align,
  showIcon = false,
  variant = "primary",
  asButton,
  type,
  onClick,
  ...rest
}) => {
  const ButtonComponent = asButton ? Button$1 : ButtonLink;
  return /* @__PURE__ */ jsx(ButtonWrapper, { $align: align, children: /* @__PURE__ */ jsxs(
    ButtonComponent,
    {
      href: !asButton ? link : void 0,
      target,
      onClick: asButton ? onClick : void 0,
      ...rest,
      $variant: variant,
      children: [
        showIcon && /* @__PURE__ */ jsx(Icon, { iconData: "arrowRight", alt: "arrow icon" }),
        children
      ]
    }
  ) });
};

export { Button as B, Container as C, FadeIn as F, Icon as I };
